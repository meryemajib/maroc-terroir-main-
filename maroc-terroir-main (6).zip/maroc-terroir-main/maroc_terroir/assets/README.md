# Assets

`images/` contains the supplied product photography used by the Flutter interface. All application assets are local; the app does not depend on remote image URLs.
