# Website-to-Flutter audit

## Website routes reproduced

| Website route | Flutter route |
| --- | --- |
| `/` | `/` |
| `/search` | `/catalog` |
| `/product/$id` | `/product` |
| `/producers` | `/producers` |
| `/producer/$id` | producer cards and product paths |
| `/cart` | `/cart` |
| `/checkout` | `/checkout` |
| `/login` | `/login` |
| `/register` | `/register` |
| `/contact` | `/contact` |
| `/a-propos` | `/a-propos` |

## Shared behaviour

- Product search, category filtering and local product data.
- Persistent-state-ready providers for product catalog and cart.
- Cart quantities, delivery fee of 25 DH, order confirmation, contact form, authentication entry routes.
- Spring API contract mirrored in `lib/services/api_service.dart`: `/auth`, `/products`, `/producers`, `/orders`, `/contact`.
- Original visual system: Nabta green, dark green, cream palette, rounded product cards and locally supplied produce photography.
- Farm location cards and deterministic six-day weather components match the source application features.

## Assets

All images supplied in the website ZIP are retained under `assets/images/` and are referenced by the Flutter widgets.
