import 'package:flutter_test/flutter_test.dart';
import 'package:maroc_terroir/main.dart';

void main() {
  testWidgets('Nabta app renders its brand', (tester) async {
    await tester.pumpWidget(const NabtaApp());
    expect(find.text('NABTA'), findsOneWidget);
  });
}
