class Product {
  const Product({
    required this.id,
    required this.name,
    required this.unit,
    required this.price,
    required this.category,
    required this.producerId,
    required this.image,
    required this.origin,
    required this.description,
    required this.delivery,
    this.bio = false,
    this.featured = false,
    this.pioneer = false,
    this.demanded = false,
  });

  final String id;
  final String name;
  final String unit;
  final int price;
  final String category;
  final String producerId;

  /// Image key resolved by [ImageService] (asset or Unsplash URL).
  final String image;
  final String origin;
  final String description;
  final String delivery;
  final bool bio;
  final bool featured;
  final bool pioneer;
  final bool demanded;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json['id'].toString(),
        name: json['name'] as String? ?? '',
        unit: json['unit'] as String? ?? '',
        price: (json['price'] as num?)?.round() ?? 0,
        category: json['category'] as String? ?? '',
        producerId: json['producerId'] as String? ?? '',
        image: json['image'] as String? ?? '',
        origin: json['origin'] as String? ?? '',
        description: json['description'] as String? ?? '',
        delivery: json['delivery'] as String? ?? '',
        bio: json['bio'] as bool? ?? false,
        featured: json['featured'] as bool? ?? false,
        pioneer: json['pioneer'] as bool? ?? false,
        demanded: json['demanded'] as bool? ?? false,
      );
}
