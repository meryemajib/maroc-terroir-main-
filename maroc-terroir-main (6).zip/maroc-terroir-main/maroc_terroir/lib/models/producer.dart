class Producer {
  const Producer({
    required this.id,
    required this.name,
    required this.city,
    required this.region,
    required this.experience,
    required this.farmSize,
    required this.productionType,
    required this.portrait,
    required this.cover,
    required this.bio,
    required this.story,
    required this.philosophy,
    required this.gallery,
    required this.lat,
    required this.lng,
    required this.weatherBase,
  });

  final String id;
  final String name;
  final String city;
  final String region;
  final int experience;
  final String farmSize;
  final String productionType;
  final String portrait;
  final String cover;
  final String bio;
  final String story;
  final String philosophy;
  final List<String> gallery;
  final double lat;
  final double lng;
  final int weatherBase;
}
