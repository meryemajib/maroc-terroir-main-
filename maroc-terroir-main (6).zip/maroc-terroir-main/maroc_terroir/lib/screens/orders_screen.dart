import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../providers/auth_provider.dart';
import '../routing/app_router.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: const BrandHeader(),
      body: ListView(padding: EdgeInsets.zero, children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 18, 20, 8),
          child: Text('Mes commandes', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
        ),
        if (!auth.isAuthenticated)
          Padding(
            padding: const EdgeInsets.all(40),
            child: Column(children: [
              const Text('Connectez-vous pour voir vos commandes.'),
              const SizedBox(height: 14),
              FilledButton(onPressed: () => Navigator.pushNamed(context, AppRouter.login), child: const Text('Se connecter')),
            ]),
          )
        else if (auth.orders.isEmpty)
          const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('Aucune commande pour le moment.')))
        else
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(children: [
              for (final o in auth.orders)
                Card(
                  child: ListTile(
                    leading: const CircleAvatar(backgroundColor: Color(0xFFEAF3E1), child: Icon(Icons.receipt_long, color: AppTheme.green)),
                    title: Text('Commande ${o.reference}', style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('${o.itemCount} article(s) · ${o.date.day}/${o.date.month}/${o.date.year}'),
                    trailing: Text('${o.total} DH', style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.green)),
                  ),
                ),
            ]),
          ),
        const SizedBox(height: 24),
        const AppFooter(),
      ]),
    );
  }
}
