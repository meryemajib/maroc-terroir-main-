import 'package:flutter/material.dart';

import '../config/app_theme.dart';
import '../services/catalog_service.dart';
import '../services/image_service.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';
import '../widgets/farm_map_card.dart';
import '../widgets/product_card.dart';
import '../widgets/weather_card.dart';

class ProducerProfileScreen extends StatelessWidget {
  const ProducerProfileScreen({super.key, required this.producerId});
  final String producerId;

  @override
  Widget build(BuildContext context) {
    final producer = CatalogService.producerById(producerId);
    if (producer == null) {
      return Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: const Center(child: Text('Producteur introuvable.')),
      );
    }
    final products = CatalogService.byProducer(producer.id);
    return Scaffold(
      appBar: const BrandHeader(showBack: true),
      body: ListView(padding: EdgeInsets.zero, children: [
        // Cover + portrait
        SizedBox(
          height: 230,
          child: Stack(clipBehavior: Clip.none, children: [
            Positioned.fill(child: AppImage(imageKey: producer.cover, networkWidth: 1200)),
            Positioned.fill(child: Container(color: Colors.black26)),
            Positioned(
              left: 20,
              bottom: 16,
              right: 20,
              child: Row(children: [
                CircleAvatar(
                  radius: 34,
                  backgroundColor: Colors.white,
                  child: ClipOval(child: AppImage(imageKey: producer.portrait, width: 64, height: 64)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(producer.name, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
                    Text('${producer.city} · ${producer.region}', style: const TextStyle(color: Colors.white70)),
                  ]),
                ),
              ]),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 8, runSpacing: 8, children: [
              _Stat(Icons.eco_outlined, producer.productionType),
              _Stat(Icons.timelapse, '${producer.experience} ans d\'expérience'),
              _Stat(Icons.crop_square, producer.farmSize),
            ]),
            const SizedBox(height: 22),
            const _H('Son histoire'),
            const SizedBox(height: 8),
            Text(producer.bio, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, height: 1.5)),
            const SizedBox(height: 10),
            Text(producer.story, style: const TextStyle(color: AppTheme.muted, height: 1.6)),
            const SizedBox(height: 20),
            const _H('Sa philosophie'),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFFEAF3E1), borderRadius: BorderRadius.circular(14)),
              child: Text(producer.philosophy, style: const TextStyle(height: 1.6, fontStyle: FontStyle.italic)),
            ),
            const SizedBox(height: 24),
            const _H('La ferme en images'),
          ]),
        ),
        SizedBox(
          height: 120,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            children: [
              for (final key in producer.gallery)
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: SizedBox(width: 160, child: AppImage(imageKey: key)),
                  ),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const _H('Localisation'),
            const SizedBox(height: 10),
            FarmMapCard(label: '${producer.name} · ${producer.city}', latitude: producer.lat, longitude: producer.lng),
            const SizedBox(height: 22),
            const _H('Météo locale (6 jours)'),
            const SizedBox(height: 10),
            WeatherCard(region: producer.region, baseTemperature: producer.weatherBase),
            const SizedBox(height: 22),
            const _H('Ses produits'),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: products.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .59, mainAxisSpacing: 12, crossAxisSpacing: 12),
            itemBuilder: (_, i) => ProductCard(product: products[i]),
          ),
        ),
        const SizedBox(height: 24),
        const AppFooter(),
      ]),
    );
  }
}

class _H extends StatelessWidget {
  const _H(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: AppTheme.darkGreen));
}

class _Stat extends StatelessWidget {
  const _Stat(this.icon, this.label);
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE0E3D8))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 16, color: AppTheme.green),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
      );
}
