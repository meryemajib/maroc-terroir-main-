import 'package:flutter/material.dart';

import '../config/app_theme.dart';
import '../models/product.dart';
import '../services/catalog_service.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';
import '../widgets/product_card.dart';

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key, this.initialQuery = ''});
  final String initialQuery;

  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  late final TextEditingController _controller;
  String _query = '';
  String _category = 'Tous';
  String _region = 'Toutes';
  double _maxPrice = 130;

  @override
  void initState() {
    super.initState();
    _query = widget.initialQuery;
    _controller = TextEditingController(text: widget.initialQuery);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final List<Product> results = CatalogService.search(
      query: _query,
      category: _category,
      region: _region,
      maxPrice: _maxPrice.round(),
    );
    return Scaffold(
      appBar: const BrandHeader(),
      body: ListView(padding: EdgeInsets.zero, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 6),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Nos produits', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
            const SizedBox(height: 4),
            const Text('Fruits, légumes et produits du terroir marocain.', style: TextStyle(color: AppTheme.muted)),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              onChanged: (v) => setState(() => _query = v),
              decoration: const InputDecoration(hintText: 'Rechercher un produit…', prefixIcon: Icon(Icons.search)),
            ),
          ]),
        ),
        SizedBox(
          height: 44,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            scrollDirection: Axis.horizontal,
            children: [
              for (final c in CatalogService.categories)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(label: Text(c), selected: _category == c, onSelected: (_) => setState(() => _category = c)),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
          child: Row(children: [
            Expanded(
              child: DropdownButtonFormField<String>(
                initialValue: _region,
                decoration: const InputDecoration(labelText: 'Région', isDense: true),
                items: [for (final r in CatalogService.regions) DropdownMenuItem(value: r, child: Text(r, overflow: TextOverflow.ellipsis))],
                onChanged: (v) => setState(() => _region = v ?? 'Toutes'),
              ),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
          child: Row(children: [
            Text('Prix max : ${_maxPrice.round()} DH', style: const TextStyle(color: AppTheme.muted)),
            Expanded(
              child: Slider(
                min: 5,
                max: 130,
                value: _maxPrice,
                label: '${_maxPrice.round()} DH',
                onChanged: (v) => setState(() => _maxPrice = v),
              ),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 6, 20, 10),
          child: Text('${results.length} produit(s)', style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
        if (results.isEmpty)
          const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('Aucun produit ne correspond à votre recherche.')))
        else
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: results.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .59, mainAxisSpacing: 12, crossAxisSpacing: 12),
              itemBuilder: (_, i) => ProductCard(product: results[i]),
            ),
          ),
        const SizedBox(height: 24),
        const AppFooter(),
      ]),
    );
  }
}
