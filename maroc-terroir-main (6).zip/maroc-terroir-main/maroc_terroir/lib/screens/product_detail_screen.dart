import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../providers/favorites_provider.dart';
import '../routing/app_router.dart';
import '../services/catalog_service.dart';
import '../services/image_service.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';
import '../widgets/product_card.dart';

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key, required this.product});
  final Product product;

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int _quantity = 1;
  late String _activeImage;

  @override
  void initState() {
    super.initState();
    _activeImage = widget.product.image;
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final producer = CatalogService.producerById(product.producerId);
    final gallery = <String>{product.image, ...?producer?.gallery}.toList();
    final similar = CatalogService.similar(product);
    final favorites = context.watch<FavoritesProvider>();
    final isFav = favorites.contains(product.id);

    return Scaffold(
      appBar: const BrandHeader(showBack: true),
      body: ListView(padding: EdgeInsets.zero, children: [
        AspectRatio(aspectRatio: 1.15, child: AppImage(imageKey: _activeImage, networkWidth: 1000)),
        SizedBox(
          height: 78,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            children: [
              for (final key in gallery)
                GestureDetector(
                  onTap: () => setState(() => _activeImage = key),
                  child: Container(
                    width: 58,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _activeImage == key ? AppTheme.green : const Color(0xFFE0E3D8), width: 2),
                    ),
                    child: ClipRRect(borderRadius: BorderRadius.circular(6), child: AppImage(imageKey: key, width: 58)),
                  ),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (product.bio) const Chip(label: Text('BIO · origine contrôlée'), backgroundColor: Color(0xFFE4F0CB)),
            Row(children: [
              Expanded(child: Text(product.name, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppTheme.darkGreen))),
              IconButton(
                onPressed: () => context.read<FavoritesProvider>().toggle(product.id),
                icon: Icon(isFav ? Icons.favorite : Icons.favorite_border, color: isFav ? const Color(0xFFE05656) : AppTheme.muted),
              ),
            ]),
            Text('${product.origin} · ${product.category}', style: const TextStyle(color: AppTheme.muted)),
            const SizedBox(height: 16),
            Text(product.description, style: const TextStyle(fontSize: 16, height: 1.5)),
            const SizedBox(height: 18),
            Row(children: [
              const Icon(Icons.local_shipping_outlined, size: 18, color: AppTheme.green),
              const SizedBox(width: 8),
              Expanded(child: Text(product.delivery.isEmpty ? 'Livraison 48h · Cueilli à la commande' : product.delivery, style: const TextStyle(color: AppTheme.muted))),
            ]),
            const Divider(height: 30),
            Row(children: [
              Text('${product.price} DH', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: AppTheme.green)),
              Text(' / ${product.unit}', style: const TextStyle(color: AppTheme.muted)),
              const Spacer(),
              _QtySelector(quantity: _quantity, onChanged: (v) => setState(() => _quantity = v)),
            ]),
            const SizedBox(height: 16),
            FilledButton.icon(
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
              onPressed: () {
                context.read<CartProvider>().add(product, quantity: _quantity);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$_quantity × ${product.name} ajouté au panier')));
              },
              icon: const Icon(Icons.shopping_bag_outlined),
              label: Text('Ajouter au panier · ${product.price * _quantity} DH'),
            ),
            if (producer != null) ...[
              const SizedBox(height: 26),
              const Text('Rencontrez le producteur', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
              const SizedBox(height: 12),
              Card(
                child: InkWell(
                  onTap: () => Navigator.pushNamed(context, AppRouter.producer, arguments: producer.id),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      CircleAvatar(radius: 30, backgroundColor: Colors.white, child: ClipOval(child: AppImage(imageKey: producer.portrait, width: 56, height: 56))),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(producer.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        Text('${producer.city} · ${producer.region}', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                        const SizedBox(height: 4),
                        Text(producer.bio, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                      ])),
                      const Icon(Icons.chevron_right, color: AppTheme.muted),
                    ]),
                  ),
                ),
              ),
            ],
            if (similar.isNotEmpty) ...[
              const SizedBox(height: 26),
              const Text('Produits similaires', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
              const SizedBox(height: 12),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: similar.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .59, mainAxisSpacing: 12, crossAxisSpacing: 12),
                itemBuilder: (_, i) => ProductCard(product: similar[i]),
              ),
            ],
          ]),
        ),
        const AppFooter(),
      ]),
    );
  }
}

class _QtySelector extends StatelessWidget {
  const _QtySelector({required this.quantity, required this.onChanged});
  final int quantity;
  final ValueChanged<int> onChanged;
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(border: Border.all(color: const Color(0xFFDCE2D7)), borderRadius: BorderRadius.circular(10)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(onPressed: quantity > 1 ? () => onChanged(quantity - 1) : null, icon: const Icon(Icons.remove)),
          Text('$quantity', style: const TextStyle(fontWeight: FontWeight.w800)),
          IconButton(onPressed: () => onChanged(quantity + 1), icon: const Icon(Icons.add)),
        ]),
      );
}
