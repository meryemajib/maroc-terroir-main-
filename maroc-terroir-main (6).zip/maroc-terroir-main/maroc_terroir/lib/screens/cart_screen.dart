import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../providers/cart_provider.dart';
import '../routing/app_router.dart';
import '../services/image_service.dart';
import '../widgets/brand_header.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return Scaffold(
      appBar: const BrandHeader(showBack: true),
      body: cart.isEmpty
          ? const _EmptyCart()
          : Column(children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 18, 20, 8),
                child: Align(alignment: Alignment.centerLeft, child: Text('Mon panier', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppTheme.darkGreen))),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: cart.items.length,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemBuilder: (_, index) {
                    final item = cart.items[index];
                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Row(children: [
                          ClipRRect(borderRadius: BorderRadius.circular(8), child: AppImage(imageKey: item.product.image, width: 62, height: 62)),
                          const SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(item.product.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            Text('${item.product.price} DH / ${item.product.unit}', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                            Text('${item.total} DH', style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.green)),
                          ])),
                          Row(children: [
                            IconButton(onPressed: () => cart.decrement(item.product), icon: const Icon(Icons.remove_circle_outline)),
                            Text('${item.quantity}', style: const TextStyle(fontWeight: FontWeight.w800)),
                            IconButton(onPressed: () => cart.add(item.product), icon: const Icon(Icons.add_circle_outline)),
                          ]),
                        ]),
                      ),
                    );
                  },
                ),
              ),
              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    Text('${cart.total} DH', style: const TextStyle(fontSize: 23, color: AppTheme.green, fontWeight: FontWeight.w800)),
                  ]),
                  const SizedBox(height: 12),
                  FilledButton(
                    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                    onPressed: () => Navigator.pushNamed(context, AppRouter.checkout),
                    child: const Text('Passer la commande'),
                  ),
                ]),
              ),
            ]),
    );
  }
}

class _EmptyCart extends StatelessWidget {
  const _EmptyCart();
  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.shopping_bag_outlined, size: 64, color: AppTheme.green),
          const SizedBox(height: 12),
          const Text('Votre panier est vide', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text('Ajoutez des produits du terroir.'),
          const SizedBox(height: 16),
          FilledButton(onPressed: () => Navigator.pushNamed(context, AppRouter.catalog), child: const Text('Découvrir les produits')),
        ]),
      );
}
