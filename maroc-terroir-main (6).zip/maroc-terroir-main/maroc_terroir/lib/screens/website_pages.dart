import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../providers/auth_provider.dart';
import '../routing/app_router.dart';
import '../services/api_service.dart';
import '../services/image_service.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';

// ---------------- About ----------------
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: ListView(padding: EdgeInsets.zero, children: [
          const _PhotoHero(imageKey: 'harvest', tag: 'Notre Histoire', title: 'Une solution pour l\'agriculture, créée avec les agriculteurs.', text: 'Nabta Market connecte directement les producteurs marocains et les consommateurs.'),
          const _TextSection(title: 'Tout a commencé dans un champ marocain', text: 'Trop de producteurs travaillent une terre généreuse sans en vivre dignement. Nabta inverse ce rapport de force par la vente directe, la transparence et un prix juste.'),
          const _TextSection(title: 'Une agriculture plus juste, plus durable', text: 'Soutenir les producteurs locaux, réduire les intermédiaires, améliorer les revenus et offrir des produits frais, cueillis à la commande.'),
          const _ValueGrid(),
          const _TextSection(title: 'Notre équipe', text: 'Une équipe passionnée d\'agronomes, de logisticiens et de designers au service du terroir marocain.'),
          const _TextSection(title: 'Notre impact', text: '10+ producteurs partenaires, 45 produits du terroir, 8 régions couvertes et 2500+ commandes livrées.'),
          const AppFooter(),
        ]),
      );
}

// ---------------- Contact ----------------
class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});
  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _subject = TextEditingController();
  final _message = TextEditingController();
  bool _sent = false;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('Contact', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
          const SizedBox(height: 8),
          const Text('Une question sur vos produits ou livraisons ? Notre équipe répond sous 24h.'),
          const SizedBox(height: 18),
          const _ContactInfo(),
          const SizedBox(height: 20),
          if (_sent)
            const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Merci, votre message a bien été envoyé.')))
          else
            Form(
              key: _form,
              child: Column(children: [
                _field(_name, 'Nom complet'),
                _field(_email, 'E-mail'),
                _field(_phone, 'Téléphone'),
                _field(_subject, 'Sujet'),
                TextFormField(controller: _message, maxLines: 5, validator: (v) => (v == null || v.isEmpty) ? 'Champ requis' : null, decoration: const InputDecoration(labelText: 'Message')),
                const SizedBox(height: 16),
                FilledButton(
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                  onPressed: () async {
                    if (!_form.currentState!.validate()) return;
                    try {
                      await const ApiService().sendContact({'fullName': _name.text, 'email': _email.text, 'phone': _phone.text, 'subject': _subject.text, 'message': _message.text});
                    } catch (_) {}
                    if (mounted) setState(() => _sent = true);
                  },
                  child: const Text('Envoyer le message'),
                ),
              ]),
            ),
          const SizedBox(height: 26),
          const Text('Questions fréquentes', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
          ...faqs.map((f) => Card(child: ExpansionTile(title: Text(f.$1), children: [Padding(padding: const EdgeInsets.all(16), child: Text(f.$2))]))),
          const SizedBox(height: 20),
          const AppFooter(),
        ]),
      );

  Widget _field(TextEditingController c, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(controller: c, validator: (v) => (v == null || v.isEmpty) ? 'Champ requis' : null, decoration: InputDecoration(labelText: label)),
      );
}

const faqs = [
  ('Comment sont livrés mes produits ?', 'Récoltés à la commande et livrés en circuit court sous 24 à 48h.'),
  ('Quelles régions livrez-vous ?', 'Casablanca, Rabat, Marrakech, Agadir, Fès et Tanger.'),
  ('Puis-je devenir producteur partenaire ?', 'Oui, contactez notre équipe avec le sujet « Partenariat producteur ».'),
  ('Quels paiements acceptez-vous ?', 'Carte, virement ou espèces à la livraison selon votre région.'),
  ('Les produits sont-ils bio ?', 'De nombreux produits sont certifiés bio, indiqués par le badge BIO.'),
];

// ---------------- Auth ----------------
class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key, this.redirect});
  final String? redirect;
  @override
  Widget build(BuildContext context) => _AuthPage(title: 'Connexion', action: 'Se connecter', alternate: 'Créer un compte', altRoute: AppRouter.register, redirect: redirect);
}

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});
  @override
  Widget build(BuildContext context) => const _AuthPage(title: 'Créer un compte', action: 'S\'inscrire', alternate: 'Se connecter', altRoute: AppRouter.login, showName: true);
}

class _AuthPage extends StatefulWidget {
  const _AuthPage({required this.title, required this.action, required this.alternate, required this.altRoute, this.showName = false, this.redirect});
  final String title, action, alternate, altRoute;
  final bool showName;
  final String? redirect;
  @override
  State<_AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<_AuthPage> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _loading = false;

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);
    final auth = context.read<AuthProvider>();
    if (widget.showName) {
      await auth.register(_name.text, _email.text, _password.text);
    } else {
      await auth.login(_email.text, _password.text);
    }
    if (!mounted) return;
    if (widget.redirect != null) {
      Navigator.pushNamedAndRemoveUntil(context, widget.redirect!, (_) => false);
    } else {
      Navigator.pushNamedAndRemoveUntil(context, AppRouter.home, (_) => false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Form(
                  key: _form,
                  child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Text(widget.title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
                    const SizedBox(height: 20),
                    if (widget.showName) ...[
                      TextFormField(controller: _name, validator: (v) => (v == null || v.isEmpty) ? 'Champ requis' : null, decoration: const InputDecoration(labelText: 'Nom complet')),
                      const SizedBox(height: 12),
                    ],
                    TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, validator: (v) => (v == null || !v.contains('@')) ? 'E-mail invalide' : null, decoration: const InputDecoration(labelText: 'E-mail')),
                    const SizedBox(height: 12),
                    TextFormField(controller: _password, obscureText: true, validator: (v) => (v == null || v.length < 4) ? '4 caractères minimum' : null, decoration: const InputDecoration(labelText: 'Mot de passe')),
                    const SizedBox(height: 18),
                    FilledButton(onPressed: _loading ? null : _submit, child: _loading ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(widget.action)),
                    TextButton(onPressed: () => Navigator.pushReplacementNamed(context, widget.altRoute), child: Text(widget.alternate)),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );
}

// ---------------- FAQ / Legal / Settings ----------------
class FaqScreen extends StatelessWidget {
  const FaqScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('Foire aux questions', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
          const SizedBox(height: 12),
          ...faqs.map((f) => Card(child: ExpansionTile(title: Text(f.$1), children: [Padding(padding: const EdgeInsets.all(16), child: Text(f.$2))]))),
          const SizedBox(height: 20),
          const AppFooter(),
        ]),
      );
}

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});
  @override
  Widget build(BuildContext context) => const _LegalPage(
        title: 'Politique de confidentialité',
        paragraphs: [
          'Nabta Market respecte votre vie privée. Nous ne collectons que les données nécessaires au traitement de vos commandes.',
          'Vos informations personnelles ne sont jamais revendues à des tiers.',
          'Vous pouvez demander la suppression de vos données à tout moment via notre page de contact.',
        ],
      );
}

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});
  @override
  Widget build(BuildContext context) => const _LegalPage(
        title: 'Conditions générales',
        paragraphs: [
          'En utilisant Nabta Market, vous acceptez nos conditions de vente et de livraison.',
          'Les prix sont indiqués en dirhams (DH) et peuvent varier selon la saison.',
          'Les produits sont cueillis à la commande et livrés en circuit court sous 24 à 72h.',
        ],
      );
}

class _LegalPage extends StatelessWidget {
  const _LegalPage({required this.title, required this.paragraphs});
  final String title;
  final List<String> paragraphs;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
          const SizedBox(height: 14),
          for (final p in paragraphs) Padding(padding: const EdgeInsets.only(bottom: 14), child: Text(p, style: const TextStyle(height: 1.6, color: AppTheme.muted))),
          const SizedBox(height: 10),
          const AppFooter(),
        ]),
      );
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: ListView(children: const [
          Padding(padding: EdgeInsets.fromLTRB(20, 18, 20, 8), child: Text('Paramètres', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: AppTheme.darkGreen))),
          ListTile(leading: Icon(Icons.language, color: AppTheme.green), title: Text('Langue'), subtitle: Text('Français')),
          ListTile(leading: Icon(Icons.notifications_outlined, color: AppTheme.green), title: Text('Notifications'), subtitle: Text('Activées')),
          ListTile(leading: Icon(Icons.location_on_outlined, color: AppTheme.green), title: Text('Région de livraison'), subtitle: Text('Casablanca-Settat')),
          ListTile(leading: Icon(Icons.info_outline, color: AppTheme.green), title: Text('Version'), subtitle: Text('Nabta Market 1.0.0')),
          AppFooter(),
        ]),
      );
}

// ---------------- Shared bits ----------------
class _PhotoHero extends StatelessWidget {
  const _PhotoHero({required this.imageKey, required this.tag, required this.title, required this.text});
  final String imageKey, tag, title, text;
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 340,
        child: Stack(fit: StackFit.expand, children: [
          AppImage(imageKey: imageKey, networkWidth: 1200),
          Container(color: Colors.black54),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Chip(label: Text(tag), backgroundColor: const Color(0xFFDCEBA9)),
              const SizedBox(height: 10),
              Text(title, style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(text, style: const TextStyle(color: Colors.white70)),
            ]),
          ),
        ]),
      );
}

class _TextSection extends StatelessWidget {
  const _TextSection({required this.title, required this.text});
  final String title, text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 23, color: AppTheme.darkGreen, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Text(text, style: const TextStyle(height: 1.6, color: AppTheme.muted)),
        ]),
      );
}

class _ValueGrid extends StatelessWidget {
  const _ValueGrid();
  @override
  Widget build(BuildContext context) => GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        padding: const EdgeInsets.all(20),
        childAspectRatio: 1.4,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        children: const [
          _ValueCard(Icons.bolt, 'Être courageux'),
          _ValueCard(Icons.favorite, 'Être humains'),
          _ValueCard(Icons.lightbulb_outline, 'Être innovants'),
          _ValueCard(Icons.eco, 'Être durables'),
        ],
      );
}

class _ValueCard extends StatelessWidget {
  const _ValueCard(this.icon, this.label);
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Card(
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: AppTheme.green, size: 28),
            const SizedBox(height: 8),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
          ]),
        ),
      );
}

class _ContactInfo extends StatelessWidget {
  const _ContactInfo();
  @override
  Widget build(BuildContext context) => const Card(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(Icons.email_outlined, size: 18, color: AppTheme.green), SizedBox(width: 8), Text('contact@nabtamarket.ma')]),
            SizedBox(height: 8),
            Row(children: [Icon(Icons.phone_outlined, size: 18, color: AppTheme.green), SizedBox(width: 8), Text('+212 5 22 00 00 00')]),
            SizedBox(height: 8),
            Row(children: [Icon(Icons.place_outlined, size: 18, color: AppTheme.green), SizedBox(width: 8), Expanded(child: Text('12 Rue des Oliviers, Casablanca'))]),
          ]),
        ),
      );
}
