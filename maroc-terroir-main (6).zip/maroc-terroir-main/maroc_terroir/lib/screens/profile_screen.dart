import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../providers/auth_provider.dart';
import '../providers/favorites_provider.dart';
import '../routing/app_router.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final favorites = context.watch<FavoritesProvider>();
    final user = auth.user;
    return Scaffold(
      appBar: const BrandHeader(),
      body: ListView(padding: EdgeInsets.zero, children: [
        Container(
          width: double.infinity,
          color: const Color(0xFFEAF3E1),
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            CircleAvatar(radius: 34, backgroundColor: AppTheme.green, child: Text(user != null ? user.name.characters.first.toUpperCase() : '?', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800))),
            const SizedBox(height: 10),
            Text(user?.name ?? 'Invité', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            if (user != null) Text(user.email, style: const TextStyle(color: AppTheme.muted)),
          ]),
        ),
        const SizedBox(height: 8),
        _tile(context, Icons.receipt_long_outlined, 'Mes commandes', '${auth.orders.length} commande(s)', AppRouter.orders),
        _tile(context, Icons.favorite_border, 'Mes favoris', '${favorites.count} produit(s)', AppRouter.favorites),
        _tile(context, Icons.shopping_bag_outlined, 'Mon panier', null, AppRouter.cart),
        _tile(context, Icons.settings_outlined, 'Paramètres', null, AppRouter.settings),
        _tile(context, Icons.info_outline, 'À propos', null, AppRouter.about),
        _tile(context, Icons.help_outline, 'FAQ', null, AppRouter.faq),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: user != null
              ? OutlinedButton.icon(
                  onPressed: () => context.read<AuthProvider>().logout(),
                  icon: const Icon(Icons.logout),
                  label: const Text('Déconnexion'),
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                )
              : FilledButton(
                  onPressed: () => Navigator.pushNamed(context, AppRouter.login),
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                  child: const Text('Se connecter'),
                ),
        ),
        const SizedBox(height: 24),
        const AppFooter(),
      ]),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, String? subtitle, String route) => ListTile(
        leading: Icon(icon, color: AppTheme.green),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: subtitle == null ? null : Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.pushNamed(context, route),
      );
}
