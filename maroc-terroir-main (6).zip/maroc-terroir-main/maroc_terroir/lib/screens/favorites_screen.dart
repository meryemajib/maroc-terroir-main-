import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../providers/favorites_provider.dart';
import '../routing/app_router.dart';
import '../services/catalog_service.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';
import '../widgets/product_card.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final favorites = context.watch<FavoritesProvider>();
    final products = CatalogService.products.where((p) => favorites.contains(p.id)).toList();
    return Scaffold(
      appBar: const BrandHeader(),
      body: ListView(padding: EdgeInsets.zero, children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 18, 20, 8),
          child: Text('Mes favoris', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
        ),
        if (products.isEmpty)
          Padding(
            padding: const EdgeInsets.all(40),
            child: Column(children: [
              const Icon(Icons.favorite_border, size: 56, color: AppTheme.green),
              const SizedBox(height: 12),
              const Text('Aucun favori pour le moment.'),
              const SizedBox(height: 14),
              FilledButton(onPressed: () => Navigator.pushNamed(context, AppRouter.catalog), child: const Text('Explorer les produits')),
            ]),
          )
        else
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: products.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .59, mainAxisSpacing: 12, crossAxisSpacing: 12),
              itemBuilder: (_, i) => ProductCard(product: products[i]),
            ),
          ),
        const SizedBox(height: 24),
        const AppFooter(),
      ]),
    );
  }
}
