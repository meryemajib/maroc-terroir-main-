import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../providers/auth_provider.dart';
import '../providers/cart_provider.dart';
import '../routing/app_router.dart';
import '../services/api_service.dart';
import '../widgets/brand_header.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _address = TextEditingController();
  final _city = TextEditingController();
  final _phone = TextEditingController();
  bool _done = false;
  static const int _shipping = 25;

  @override
  void initState() {
    super.initState();
    final user = context.read<AuthProvider>().user;
    if (user != null) _name.text = user.name;
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final cart = context.watch<CartProvider>();

    // Checkout requires authentication (cart is preserved during login).
    if (!auth.isAuthenticated) {
      return Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.lock_outline, size: 56, color: AppTheme.green),
              const SizedBox(height: 14),
              const Text('Connectez-vous pour finaliser', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
              const SizedBox(height: 8),
              const Text('Votre panier est conservé. Vous reviendrez ici après connexion.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 18),
              FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                onPressed: () => Navigator.pushReplacementNamed(context, AppRouter.login, arguments: AppRouter.checkout),
                child: const Text('Se connecter'),
              ),
            ]),
          ),
        ),
      );
    }

    if (_done) {
      return Scaffold(
        appBar: const BrandHeader(showBack: true),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.check_circle_outline, size: 64, color: AppTheme.green),
              const SizedBox(height: 14),
              const Text('Commande confirmée', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text('Merci ! Vos producteurs préparent votre commande.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 18),
              FilledButton(onPressed: () => Navigator.pushNamedAndRemoveUntil(context, AppRouter.orders, (_) => false), child: const Text('Voir mes commandes')),
            ]),
          ),
        ),
      );
    }

    final total = cart.total + _shipping;
    return Scaffold(
      appBar: const BrandHeader(showBack: true),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Finaliser la commande', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
        const SizedBox(height: 16),
        Form(
          key: _form,
          child: Column(children: [
            _field(_name, 'Nom complet'),
            _field(_address, 'Adresse'),
            _field(_city, 'Ville'),
            _field(_phone, 'Téléphone'),
          ]),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              _row('Sous-total', '${cart.total} DH'),
              _row('Livraison', '$_shipping DH'),
              const Divider(),
              _row('Total', '$total DH', bold: true),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
          onPressed: () async {
            if (!_form.currentState!.validate()) return;
            try {
              await const ApiService().createOrder({
                'customerName': _name.text,
                'address': _address.text,
                'city': _city.text,
                'phone': _phone.text,
                'total': total,
              });
            } catch (_) {}
            context.read<AuthProvider>().addOrder(OrderRecord(
                  reference: 'NB-${DateTime.now().millisecondsSinceEpoch % 100000}',
                  date: DateTime.now(),
                  total: total,
                  itemCount: cart.itemCount,
                ));
            cart.clear();
            if (mounted) setState(() => _done = true);
          },
          child: Text('Payer $total DH'),
        ),
      ]),
    );
  }

  Widget _field(TextEditingController c, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(controller: c, validator: (v) => (v == null || v.isEmpty) ? 'Champ requis' : null, decoration: InputDecoration(labelText: label)),
      );

  Widget _row(String label, String value, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w400)),
          Text(value, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w600, color: bold ? AppTheme.green : null)),
        ]),
      );
}
