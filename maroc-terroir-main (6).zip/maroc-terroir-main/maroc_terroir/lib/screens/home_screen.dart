import 'package:flutter/material.dart';

import '../config/app_theme.dart';
import '../routing/app_router.dart';
import '../services/catalog_service.dart';
import '../services/image_service.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';
import '../widgets/producer_card.dart';
import '../widgets/product_card.dart';
import '../widgets/section_heading.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const _steps = [
    ('1', 'Choisir un produit', 'Parcourez fruits, légumes et produits du terroir cueillis à la commande.'),
    ('2', 'Ajouter au panier', 'Composez votre panier de saison auprès de plusieurs producteurs.'),
    ('3', 'Passer commande', 'Validez en quelques clics, votre commande est préparée à la ferme.'),
    ('4', 'Recevoir sa commande', 'Livraison en circuit court, en 48h, au plus frais.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const BrandHeader(),
      body: ListView(padding: EdgeInsets.zero, children: [
        _Hero(onProducts: () => Navigator.pushNamed(context, AppRouter.catalog), onProducers: () => Navigator.pushNamed(context, AppRouter.producers)),
        const _TrustStrip(),
        _sectionHeader('Produits de la semaine', 'Une sélection de fruits et légumes de saison cueillis cette semaine par nos producteurs.'),
        _grid(CatalogService.weekly),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
          child: FilledButton(onPressed: () => Navigator.pushNamed(context, AppRouter.catalog), child: const Text('Voir tous les produits')),
        ),
        Container(color: const Color(0xFFF7F5EC), child: Column(children: [
          _sectionHeader('Produits les plus demandés', 'Les pépites du terroir plébiscitées par notre communauté, livrées directement de la ferme.'),
          _grid(CatalogService.demanded),
          const SizedBox(height: 10),
        ])),
        _sectionHeader("Les pionniers de l'agriculture durable", "Des produits d'exception issus de fermes qui réinventent une agriculture respectueuse de la terre."),
        _grid(CatalogService.pioneers),
        Container(color: const Color(0xFFF7F5EC), child: Column(children: [
          _sectionHeader('Producteurs à découvrir', 'Derrière chaque produit, une famille, une ferme et une histoire.'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(children: [
              for (final producer in CatalogService.featuredProducers)
                Padding(padding: const EdgeInsets.only(bottom: 14), child: ProducerCard(producer: producer)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: FilledButton(onPressed: () => Navigator.pushNamed(context, AppRouter.producers), child: const Text('Voir tous les producteurs')),
          ),
        ])),
        _sectionHeader('Comment ça marche', 'De la ferme à votre table en quatre étapes simples.'),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Column(children: [for (final step in _steps) _StepCard(step: step)]),
        ),
        const _CtaBand(),
        const AppFooter(),
      ]),
    );
  }

  Widget _sectionHeader(String title, String subtitle) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 28, 20, 14),
        child: SectionHeading(title: title, subtitle: subtitle),
      );

  Widget _grid(List products) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: products.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .59, mainAxisSpacing: 12, crossAxisSpacing: 12),
          itemBuilder: (_, i) => ProductCard(product: products[i]),
        ),
      );
}

class _Hero extends StatelessWidget {
  const _Hero({required this.onProducts, required this.onProducers});
  final VoidCallback onProducts;
  final VoidCallback onProducers;
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 420,
        child: Stack(fit: StackFit.expand, children: [
          AppImage(imageKey: 'heroFarm', networkWidth: 1200),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Colors.black.withOpacity(.78), Colors.black.withOpacity(.15)], begin: Alignment.bottomLeft, end: Alignment.topRight),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Chip(label: Text('Agriculture durable · Circuits courts', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800)), backgroundColor: Color(0xFFDCEBA9)),
              const SizedBox(height: 14),
              const Text('Le meilleur du terroir marocain, en direct des producteurs', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800, height: 1.08)),
              const SizedBox(height: 12),
              const Text("Fruits, légumes, huile d'olive et miel cueillis à la commande et livrés chez vous. Sans intermédiaire, au juste prix.", style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 18),
              Wrap(spacing: 12, runSpacing: 10, children: [
                FilledButton.icon(onPressed: onProducts, icon: const Icon(Icons.arrow_forward), label: const Text('Découvrir les produits')),
                OutlinedButton(onPressed: onProducers, style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54)), child: const Text('Nos producteurs')),
              ]),
            ]),
          ),
        ]),
      );
}

class _TrustStrip extends StatelessWidget {
  const _TrustStrip();
  @override
  Widget build(BuildContext context) => Container(
        color: const Color(0xFFF0F1DE),
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
        child: const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          _Trust('10+', 'Producteurs'),
          _Trust('100%', 'Origine Maroc'),
          _Trust('48h', 'Circuit court'),
          _Trust('0', 'Intermédiaire'),
        ]),
      );
}

class _Trust extends StatelessWidget {
  const _Trust(this.number, this.label);
  final String number;
  final String label;
  @override
  Widget build(BuildContext context) => Column(children: [
        Text(number, style: const TextStyle(color: AppTheme.green, fontWeight: FontWeight.w800, fontSize: 22)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(fontSize: 10, color: AppTheme.darkGreen)),
      ]);
}

class _StepCard extends StatelessWidget {
  const _StepCard({required this.step});
  final (String, String, String) step;
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 22, backgroundColor: AppTheme.green, child: Text(step.$1, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18))),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(step.$2, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(height: 4),
              Text(step.$3, style: const TextStyle(color: AppTheme.muted, height: 1.4)),
            ])),
          ]),
        ),
      );
}

class _CtaBand extends StatelessWidget {
  const _CtaBand();
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 260,
        child: Stack(fit: StackFit.expand, children: [
          AppImage(imageKey: 'field', networkWidth: 1200),
          Container(color: AppTheme.darkGreen.withOpacity(.72)),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Soutenez une agriculture juste et locale', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              const Text('Chaque commande rémunère équitablement le producteur et préserve le terroir marocain.', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 16),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppTheme.darkGreen),
                onPressed: () => Navigator.pushNamed(context, AppRouter.catalog),
                child: const Text('Commencer mes achats'),
              ),
            ]),
          ),
        ]),
      );
}
