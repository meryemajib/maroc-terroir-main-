import 'package:flutter/material.dart';

import '../config/app_theme.dart';
import '../models/producer.dart';
import '../services/catalog_service.dart';
import '../widgets/app_footer.dart';
import '../widgets/brand_header.dart';
import '../widgets/producer_card.dart';

class ProducersScreen extends StatefulWidget {
  const ProducersScreen({super.key});

  @override
  State<ProducersScreen> createState() => _ProducersScreenState();
}

class _ProducersScreenState extends State<ProducersScreen> {
  String _query = '';
  String _region = 'Toutes';

  @override
  Widget build(BuildContext context) {
    final q = _query.trim().toLowerCase();
    final List<Producer> results = CatalogService.producers.where((p) {
      final matchesRegion = _region == 'Toutes' || p.region == _region;
      final matchesQuery = q.isEmpty ||
          p.name.toLowerCase().contains(q) ||
          p.city.toLowerCase().contains(q) ||
          p.bio.toLowerCase().contains(q);
      return matchesRegion && matchesQuery;
    }).toList(growable: false);

    return Scaffold(
      appBar: const BrandHeader(),
      body: ListView(padding: EdgeInsets.zero, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 6),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Nos producteurs', style: TextStyle(fontSize: 27, color: AppTheme.darkGreen, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('Des familles et des fermes qui font vivre le terroir marocain.', style: TextStyle(color: AppTheme.muted)),
            const SizedBox(height: 14),
            TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: const InputDecoration(hintText: 'Rechercher un producteur…', prefixIcon: Icon(Icons.search)),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: _region,
              decoration: const InputDecoration(labelText: 'Région', isDense: true),
              items: [for (final r in CatalogService.regions) DropdownMenuItem(value: r, child: Text(r, overflow: TextOverflow.ellipsis))],
              onChanged: (v) => setState(() => _region = v ?? 'Toutes'),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
          child: Text('${results.length} producteur(s)', style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(children: [
            for (final producer in results)
              Padding(padding: const EdgeInsets.only(bottom: 14), child: ProducerCard(producer: producer)),
          ]),
        ),
        const SizedBox(height: 24),
        const AppFooter(),
      ]),
    );
  }
}
