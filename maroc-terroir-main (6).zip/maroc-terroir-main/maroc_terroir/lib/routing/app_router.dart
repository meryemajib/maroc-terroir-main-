import 'package:flutter/material.dart';

import '../models/product.dart';
import '../screens/cart_screen.dart';
import '../screens/catalog_screen.dart';
import '../screens/checkout_screen.dart';
import '../screens/favorites_screen.dart';
import '../screens/home_screen.dart';
import '../screens/orders_screen.dart';
import '../screens/producer_profile_screen.dart';
import '../screens/producers_screen.dart';
import '../screens/product_detail_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/website_pages.dart';

abstract final class AppRouter {
  static const home = '/';
  static const catalog = '/products';
  static const search = '/search';
  static const producers = '/producers';
  static const producer = '/producer';
  static const product = '/product';
  static const cart = '/cart';
  static const checkout = '/checkout';
  static const favorites = '/favorites';
  static const orders = '/orders';
  static const profile = '/profile';
  static const about = '/a-propos';
  static const contact = '/contact';
  static const faq = '/faq';
  static const privacy = '/privacy';
  static const terms = '/terms';
  static const settings = '/settings';
  static const login = '/login';
  static const register = '/register';

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    Widget page;
    switch (settings.name) {
      case catalog:
      case search:
        page = CatalogScreen(initialQuery: settings.arguments is String ? settings.arguments as String : '');
        break;
      case producers:
        page = const ProducersScreen();
        break;
      case producer:
        page = ProducerProfileScreen(producerId: settings.arguments! as String);
        break;
      case product:
        page = ProductDetailScreen(product: settings.arguments! as Product);
        break;
      case cart:
        page = const CartScreen();
        break;
      case checkout:
        page = const CheckoutScreen();
        break;
      case favorites:
        page = const FavoritesScreen();
        break;
      case orders:
        page = const OrdersScreen();
        break;
      case profile:
        page = const ProfileScreen();
        break;
      case about:
        page = const AboutScreen();
        break;
      case contact:
        page = const ContactScreen();
        break;
      case faq:
        page = const FaqScreen();
        break;
      case privacy:
        page = const PrivacyScreen();
        break;
      case terms:
        page = const TermsScreen();
        break;
      case AppRouter.settings:
        page = const SettingsScreen();
        break;
      case login:
        final redirect = settings.arguments is String ? settings.arguments as String : null;
        page = LoginScreen(redirect: redirect);
        break;
      case register:
        page = const RegisterScreen();
        break;
      case home:
      default:
        page = const HomeScreen();
    }
    return MaterialPageRoute(builder: (_) => page, settings: settings);
  }
}
