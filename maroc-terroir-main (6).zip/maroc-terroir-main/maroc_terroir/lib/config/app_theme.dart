import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

abstract final class AppTheme {
  static const green = Color(0xFF35834C);
  static const darkGreen = Color(0xFF1F4F31);
  static const cream = Color(0xFFFFFCF5);
  static const warmWhite = Color(0xFFFFFEFA);
  static const muted = Color(0xFF68756A);

  static final light = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: green,
      brightness: Brightness.light,
      surface: warmWhite,
    ),
    scaffoldBackgroundColor: cream,
    textTheme: GoogleFonts.dmSansTextTheme().copyWith(
      displayLarge: GoogleFonts.fraunces(fontWeight: FontWeight.w700),
      displayMedium: GoogleFonts.fraunces(fontWeight: FontWeight.w700),
      headlineLarge: GoogleFonts.fraunces(fontWeight: FontWeight.w700),
      headlineMedium: GoogleFonts.fraunces(fontWeight: FontWeight.w700),
      titleLarge: GoogleFonts.fraunces(fontWeight: FontWeight.w600),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: cream,
      foregroundColor: darkGreen,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    cardTheme: CardThemeData(
      color: warmWhite,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFFE3E7DD)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: warmWhite,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFDCE2D7)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFDCE2D7)),
      ),
    ),
  );
}
