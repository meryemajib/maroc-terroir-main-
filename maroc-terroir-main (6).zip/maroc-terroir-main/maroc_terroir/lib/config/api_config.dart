abstract final class ApiConfig {
  // Supply --dart-define=NABTA_API_URL=https://your-host at build time.
  static const baseUrl = String.fromEnvironment('NABTA_API_URL', defaultValue: 'http://localhost:8080');
  static String get apiUrl => '${baseUrl.replaceFirst(RegExp(r'/$'), '')}/api';
}
