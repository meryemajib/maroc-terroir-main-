import 'dart:math' as math;

import 'package:flutter/material.dart';
import '../config/app_theme.dart';

/// Interactive-style map using real OpenStreetMap tiles for the farm location.
class FarmMapCard extends StatelessWidget {
  const FarmMapCard({super.key, required this.label, required this.latitude, required this.longitude});
  final String label;
  final double latitude;
  final double longitude;

  static const _zoom = 11;

  int get _tileX => ((longitude + 180.0) / 360.0 * (1 << _zoom)).floor();

  int get _tileY {
    final latRad = latitude * math.pi / 180.0;
    return ((1 - (math.log(math.tan(latRad) + 1 / math.cos(latRad)) / math.pi)) / 2 * (1 << _zoom)).floor();
  }

  String get _tileUrl => 'https://tile.openstreetmap.org/$_zoom/$_tileX/$_tileY.png';

  @override
  Widget build(BuildContext context) => Card(
        clipBehavior: Clip.antiAlias,
        child: Column(children: [
          SizedBox(
            height: 200,
            width: double.infinity,
            child: Stack(fit: StackFit.expand, children: [
              Image.network(
                _tileUrl,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: const Color(0xFFE6EEE0)),
              ),
              const Center(child: Icon(Icons.location_on, color: AppTheme.green, size: 44)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Flexible(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700))),
              Text('${latitude.toStringAsFixed(3)}, ${longitude.toStringAsFixed(3)}', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
            ]),
          ),
        ]),
      );
}
