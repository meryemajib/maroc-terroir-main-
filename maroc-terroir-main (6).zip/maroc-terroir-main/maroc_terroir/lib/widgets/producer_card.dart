import 'package:flutter/material.dart';

import '../config/app_theme.dart';
import '../models/producer.dart';
import '../routing/app_router.dart';
import '../services/image_service.dart';

class ProducerCard extends StatelessWidget {
  const ProducerCard({super.key, required this.producer});

  final Producer producer;

  @override
  Widget build(BuildContext context) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.pushNamed(context, AppRouter.producer, arguments: producer.id),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(
              height: 120,
              width: double.infinity,
              child: Stack(fit: StackFit.expand, children: [
                AppImage(imageKey: producer.cover),
                Positioned(
                  left: 12,
                  bottom: -22,
                  child: CircleAvatar(
                    radius: 26,
                    backgroundColor: Colors.white,
                    child: ClipOval(
                      child: AppImage(imageKey: producer.portrait, width: 48, height: 48),
                    ),
                  ),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 28, 14, 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(producer.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
                const SizedBox(height: 2),
                Row(children: [
                  const Icon(Icons.place_outlined, size: 14, color: AppTheme.muted),
                  const SizedBox(width: 3),
                  Text('${producer.city} · ${producer.region}', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                ]),
                const SizedBox(height: 8),
                Text(producer.bio, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, height: 1.35)),
                const SizedBox(height: 10),
                Row(children: [
                  _Tag(producer.productionType),
                  const Spacer(),
                  const Text('Voir la ferme →', style: TextStyle(color: AppTheme.green, fontWeight: FontWeight.w700, fontSize: 12)),
                ]),
              ]),
            ),
          ]),
        ),
      );
}

class _Tag extends StatelessWidget {
  const _Tag(this.label);
  final String label;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(color: const Color(0xFFEAF3E1), borderRadius: BorderRadius.circular(20)),
        child: Text(label, style: const TextStyle(fontSize: 10, color: AppTheme.darkGreen, fontWeight: FontWeight.w700)),
      );
}
