import 'package:flutter/material.dart';
import '../config/app_theme.dart';

/// Deterministic forecast identical to `forecastFor` in src/data/catalog.ts.
class WeatherCard extends StatelessWidget {
  const WeatherCard({super.key, required this.region, required this.baseTemperature});
  final String region;
  final int baseTemperature;

  static const _days = ['Auj.', 'Demain', 'Mer.', 'Jeu.', 'Ven.', 'Sam.'];
  static const _conditions = ['Ensoleillé', 'Peu nuageux', 'Ensoleillé', 'Nuageux', 'Ensoleillé', 'Éclaircies'];

  IconData _icon(String condition) {
    switch (condition) {
      case 'Nuageux':
        return Icons.cloud_outlined;
      case 'Peu nuageux':
      case 'Éclaircies':
        return Icons.cloud_queue;
      default:
        return Icons.wb_sunny_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final temps = List.generate(6, (i) => baseTemperature + ((i * 7) % 5) - 2);
    final todayCondition = _conditions.first;
    return Card(
      color: const Color(0xFFEAF3E1),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Météo · $region', style: const TextStyle(color: AppTheme.muted)),
              Text('${temps.first}°C', style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
              Text(todayCondition, style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
            CircleAvatar(radius: 28, backgroundColor: Colors.white70, child: Icon(_icon(todayCondition), color: AppTheme.green, size: 30)),
          ]),
          const SizedBox(height: 14),
          Row(
            children: List.generate(6, (i) {
              final condition = _conditions[i % _conditions.length];
              return Expanded(
                child: Column(children: [
                  Text(_days[i], style: const TextStyle(fontSize: 10, color: AppTheme.muted)),
                  const SizedBox(height: 4),
                  Icon(_icon(condition), size: 16, color: AppTheme.green),
                  const SizedBox(height: 4),
                  Text('${temps[i]}°', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                ]),
              );
            }),
          ),
        ]),
      ),
    );
  }
}
