import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../providers/favorites_provider.dart';
import '../routing/app_router.dart';
import '../services/image_service.dart';

class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.product});

  final Product product;

  @override
  Widget build(BuildContext context) {
    final favorites = context.watch<FavoritesProvider>();
    final isFav = favorites.contains(product.id);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.pushNamed(context, AppRouter.product, arguments: product),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            flex: 6,
            child: Stack(fit: StackFit.expand, children: [
              AppImage(imageKey: product.image),
              if (product.bio)
                const Positioned(
                  top: 8,
                  left: 8,
                  child: Chip(
                    padding: EdgeInsets.zero,
                    visualDensity: VisualDensity.compact,
                    label: Text('BIO', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800)),
                    backgroundColor: Color(0xFFE4F0CB),
                  ),
                ),
              Positioned(
                top: 4,
                right: 4,
                child: IconButton(
                  tooltip: isFav ? 'Retirer des favoris' : 'Ajouter aux favoris',
                  onPressed: () => context.read<FavoritesProvider>().toggle(product.id),
                  icon: Icon(
                    isFav ? Icons.favorite : Icons.favorite_border,
                    color: isFav ? const Color(0xFFE05656) : Colors.white,
                  ),
                ),
              ),
            ]),
          ),
          Expanded(
            flex: 5,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 8, 7),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(product.category, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: AppTheme.muted)),
                const SizedBox(height: 2),
                Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(product.origin, style: const TextStyle(fontSize: 11, color: AppTheme.muted)),
                const Spacer(),
                Row(children: [
                  Text('${product.price} DH', style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.green)),
                  Text(' / ${product.unit}', style: const TextStyle(fontSize: 10)),
                  const Spacer(),
                  SizedBox(
                    height: 30,
                    width: 30,
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      tooltip: 'Ajouter au panier',
                      style: IconButton.styleFrom(backgroundColor: AppTheme.green, foregroundColor: Colors.white),
                      onPressed: () {
                        context.read<CartProvider>().add(product);
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${product.name} ajouté au panier'), duration: const Duration(seconds: 1)));
                      },
                      icon: const Icon(Icons.add, size: 18),
                    ),
                  ),
                ]),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
