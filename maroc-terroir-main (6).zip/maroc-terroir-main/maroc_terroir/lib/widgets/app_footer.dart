import 'package:flutter/material.dart';

import '../config/app_theme.dart';
import '../routing/app_router.dart';

/// Footer shown on every page, mirroring src/components/Footer.tsx.
class AppFooter extends StatelessWidget {
  const AppFooter({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFF3F1E7),
      padding: const EdgeInsets.fromLTRB(24, 34, 24, 26),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            height: 36,
            width: 36,
            alignment: Alignment.center,
            decoration: const BoxDecoration(color: AppTheme.green, shape: BoxShape.circle),
            child: const Text('N', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
          ),
          const SizedBox(width: 8),
          Text('Nabta Market', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 19, color: AppTheme.darkGreen)),
        ]),
        const SizedBox(height: 12),
        const Text(
          'La marketplace qui relie directement les producteurs marocains aux gourmets, pour une agriculture durable et locale.',
          style: TextStyle(color: AppTheme.muted, height: 1.5),
        ),
        const SizedBox(height: 14),
        Wrap(spacing: 8, children: const [
          _Social('Instagram'),
          _Social('Facebook'),
          _Social('LinkedIn'),
        ]),
        const SizedBox(height: 24),
        _LinkColumn(title: 'Nabta Market', links: [
          ('À propos', AppRouter.about),
          ('Contact', AppRouter.contact),
          ('FAQ', AppRouter.faq),
          ('Conditions générales', AppRouter.terms),
          ('Politique de confidentialité', AppRouter.privacy),
        ]),
        const SizedBox(height: 20),
        _LinkColumn(title: 'Explorer', links: [
          ('Produits', AppRouter.catalog),
          ('Producteurs', AppRouter.producers),
          ('Favoris', AppRouter.favorites),
          ('Mon compte', AppRouter.profile),
        ]),
        const SizedBox(height: 24),
        const Divider(),
        const SizedBox(height: 12),
        Text('© ${DateTime.now().year} Nabta Market. Tous droits réservés.', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
      ]),
    );
  }
}

class _Social extends StatelessWidget {
  const _Social(this.label);
  final String label;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE0E3D8))),
        child: Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.muted, fontWeight: FontWeight.w600)),
      );
}

class _LinkColumn extends StatelessWidget {
  const _LinkColumn({required this.title, required this.links});
  final String title;
  final List<(String, String)> links;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title.toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: .5)),
        const SizedBox(height: 8),
        for (final link in links)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: GestureDetector(
              onTap: () => Navigator.pushNamed(context, link.$2),
              child: Text(link.$1, style: const TextStyle(color: AppTheme.muted)),
            ),
          ),
      ]);
}
