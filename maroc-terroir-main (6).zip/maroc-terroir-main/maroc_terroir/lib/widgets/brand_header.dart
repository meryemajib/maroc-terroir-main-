import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_theme.dart';
import '../providers/auth_provider.dart';
import '../providers/cart_provider.dart';
import '../routing/app_router.dart';

class BrandHeader extends StatefulWidget implements PreferredSizeWidget {
  const BrandHeader({super.key, this.showBack = false});

  final bool showBack;

  @override
  Size get preferredSize => const Size.fromHeight(64);

  @override
  State<BrandHeader> createState() => _BrandHeaderState();
}

class _BrandHeaderState extends State<BrandHeader> {
  bool open = false;

  static const _nav = [
    ('Accueil', AppRouter.home),
    ('Produits', AppRouter.catalog),
    ('Producteurs', AppRouter.producers),
    ('Notre Histoire', AppRouter.about),
    ('Contact', AppRouter.contact),
    ('Favoris', AppRouter.favorites),
    ('Mon compte', AppRouter.profile),
  ];

  @override
  Widget build(BuildContext context) {
    final count = context.watch<CartProvider>().itemCount;
    final auth = context.watch<AuthProvider>();
    return AppBar(
      leading: widget.showBack ? const BackButton() : null,
      titleSpacing: widget.showBack ? 0 : 20,
      title: InkWell(
        onTap: () => Navigator.pushNamedAndRemoveUntil(context, AppRouter.home, (_) => false),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
            height: 36,
            width: 36,
            alignment: Alignment.center,
            decoration: const BoxDecoration(color: AppTheme.green, shape: BoxShape.circle),
            child: Text('N', style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(width: 8),
          Flexible(child: Text('Nabta Market', overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 19, color: AppTheme.darkGreen))),
        ]),
      ),
      actions: [
        IconButton(
          tooltip: 'Panier',
          onPressed: () => Navigator.pushNamed(context, AppRouter.cart),
          icon: Badge(
            isLabelVisible: count > 0,
            label: Text('$count'),
            child: const Icon(Icons.shopping_bag_outlined),
          ),
        ),
        IconButton(tooltip: 'Menu', onPressed: () => setState(() => open = !open), icon: Icon(open ? Icons.close : Icons.menu)),
      ],
      bottom: open
          ? PreferredSize(
              preferredSize: const Size.fromHeight(300),
              child: Container(
                color: AppTheme.cream,
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  for (final item in _nav) _NavItem(item.$1, item.$2),
                  const Divider(),
                  if (auth.isAuthenticated)
                    TextButton(
                      style: TextButton.styleFrom(alignment: Alignment.centerLeft),
                      onPressed: () {
                        context.read<AuthProvider>().logout();
                        setState(() => open = false);
                      },
                      child: Text('Déconnexion (${auth.user!.name})'),
                    )
                  else
                    _NavItem('Connexion', AppRouter.login),
                ]),
              ),
            )
          : null,
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem(this.label, this.route);
  final String label;
  final String route;
  @override
  Widget build(BuildContext context) => TextButton(
        onPressed: () => Navigator.pushNamedAndRemoveUntil(context, route, (_) => false),
        style: TextButton.styleFrom(alignment: Alignment.centerLeft),
        child: Text(label),
      );
}
