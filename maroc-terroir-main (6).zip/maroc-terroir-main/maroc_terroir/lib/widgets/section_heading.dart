import 'package:flutter/material.dart';

import '../config/app_theme.dart';

class SectionHeading extends StatelessWidget {
  const SectionHeading({super.key, required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 25, height: 1.1, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: AppTheme.muted)),
        ],
      );
}
