import '../data/catalog_data.dart';
import '../models/producer.dart';
import '../models/product.dart';

/// Read-only queries over the generated catalog (single source of truth).
abstract final class CatalogService {
  static List<Product> get products => CatalogData.products;
  static List<Producer> get producers => CatalogData.producers;

  /// Website exposes "Tous" plus the real categories for the filter bar.
  static List<String> get categories => ['Tous', ...CatalogData.categories];

  static List<String> get regions {
    final set = <String>{for (final p in producers) p.region};
    final list = set.toList()..sort();
    return ['Toutes', ...list];
  }

  static Product? productById(String id) {
    for (final p in products) {
      if (p.id == id) return p;
    }
    return null;
  }

  static Producer? producerById(String id) {
    for (final p in producers) {
      if (p.id == id) return p;
    }
    return null;
  }

  static String producerName(String id) => producerById(id)?.name ?? 'Producteur';

  static List<Product> byProducer(String producerId) =>
      products.where((p) => p.producerId == producerId).toList(growable: false);

  static List<Product> similar(Product product) => products
      .where((p) => p.id != product.id && p.category == product.category)
      .take(4)
      .toList(growable: false);

  // Home sections (mirrors src/routes/index.tsx).
  static List<Product> get weekly => products
      .where((p) => p.category == 'Légumes' || p.category == 'Fruits')
      .take(4)
      .toList(growable: false);

  static List<Product> get demanded =>
      products.where((p) => p.demanded).take(4).toList(growable: false);

  static List<Product> get pioneers =>
      products.where((p) => p.pioneer).take(4).toList(growable: false);

  static List<Producer> get featuredProducers => producers.take(4).toList(growable: false);

  /// Filtered product search used by the Products screen.
  static List<Product> search({
    String query = '',
    String category = 'Tous',
    String region = 'Toutes',
    int? maxPrice,
  }) {
    final q = query.trim().toLowerCase();
    return products.where((p) {
      final matchesCategory = category == 'Tous' || p.category == category;
      final producer = producerById(p.producerId);
      final matchesRegion = region == 'Toutes' || producer?.region == region;
      final matchesQuery = q.isEmpty ||
          p.name.toLowerCase().contains(q) ||
          p.origin.toLowerCase().contains(q) ||
          p.description.toLowerCase().contains(q);
      final matchesPrice = maxPrice == null || p.price <= maxPrice;
      return matchesCategory && matchesRegion && matchesQuery && matchesPrice;
    }).toList(growable: false);
  }
}
