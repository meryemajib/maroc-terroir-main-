import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class ApiService {
  const ApiService();
  Future<void> sendContact(Map<String, String> data) async {
    await _post('/contact', data);
  }
  Future<void> createOrder(Map<String, Object> data, {String? token}) async {
    await _post('/orders', data, token: token);
  }
  Future<Map<String, dynamic>> login(String email, String password) => _post('/auth/login', {'email': email, 'password': password});
  Future<Map<String, dynamic>> register(String name, String email, String password) => _post('/auth/register', {'name': name, 'email': email, 'password': password});
  Future<Map<String, dynamic>> _post(String path, Object body, {String? token}) async {
    final response = await http.post(Uri.parse('${ApiConfig.apiUrl}$path'), headers: {'Content-Type': 'application/json', if (token != null) 'Authorization': 'Bearer $token'}, body: jsonEncode(body));
    if (response.statusCode < 200 || response.statusCode >= 300) throw ApiException(response.statusCode, response.body);
    return response.body.isEmpty ? <String, dynamic>{} : jsonDecode(response.body) as Map<String, dynamic>;
  }
}
class ApiException implements Exception { const ApiException(this.status, this.message); final int status; final String message; }
