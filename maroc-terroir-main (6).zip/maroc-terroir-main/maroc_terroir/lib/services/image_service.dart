import 'package:flutter/material.dart';

import '../data/catalog_data.dart';

/// Resolves catalog image keys to a concrete image (local asset or Unsplash URL),
/// mirroring the website's `img()` helper in src/data/catalog.ts.
abstract final class ImageService {
  static bool isLocal(String key) => CatalogData.localKeys.contains(key);

  static String assetPath(String key) => 'assets/images/$key.jpg';

  static String url(String key, {int width = 800}) {
    final id = CatalogData.unsplashIds[key];
    if (id == null) return '';
    return 'https://images.unsplash.com/photo-$id?auto=format&fit=crop&w=$width&q=80';
  }
}

/// Unified image widget: renders a local asset when available, otherwise a
/// network image, with graceful loading + error fallbacks.
class AppImage extends StatelessWidget {
  const AppImage({
    super.key,
    required this.imageKey,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.networkWidth = 800,
  });

  final String imageKey;
  final BoxFit fit;
  final double? width;
  final double? height;
  final int networkWidth;

  @override
  Widget build(BuildContext context) {
    if (ImageService.isLocal(imageKey)) {
      return Image.asset(
        ImageService.assetPath(imageKey),
        fit: fit,
        width: width,
        height: height,
        errorBuilder: (_, __, ___) => _fallback(),
      );
    }
    final url = ImageService.url(imageKey, width: networkWidth);
    if (url.isEmpty) return _fallback();
    return Image.network(
      url,
      fit: fit,
      width: width,
      height: height,
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return _placeholder();
      },
      errorBuilder: (_, __, ___) => _fallback(),
    );
  }

  Widget _placeholder() => Container(
        width: width,
        height: height,
        color: const Color(0xFFEDEFE6),
        child: const Center(
          child: SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
        ),
      );

  Widget _fallback() => Container(
        width: width,
        height: height,
        color: const Color(0xFFEDEFE6),
        child: const Icon(Icons.image_not_supported_outlined, color: Color(0xFF9AA69A)),
      );
}
