import 'package:flutter/foundation.dart';

import '../models/cart_item.dart';
import '../models/product.dart';

class CartProvider extends ChangeNotifier {
  final Map<String, CartItem> _items = {};

  List<CartItem> get items => _items.values.toList(growable: false);
  int get itemCount => _items.values.fold(0, (sum, item) => sum + item.quantity);
  int get total => _items.values.fold(0, (sum, item) => sum + item.total);
  bool get isEmpty => _items.isEmpty;

  int quantityOf(String productId) => _items[productId]?.quantity ?? 0;

  void add(Product product, {int quantity = 1}) {
    final current = _items[product.id];
    _items[product.id] = CartItem(
      product: product,
      quantity: (current?.quantity ?? 0) + quantity,
    );
    notifyListeners();
  }

  void setQuantity(Product product, int quantity) {
    if (quantity <= 0) {
      _items.remove(product.id);
    } else {
      _items[product.id] = CartItem(product: product, quantity: quantity);
    }
    notifyListeners();
  }

  void decrement(Product product) {
    final current = _items[product.id];
    if (current == null) return;
    if (current.quantity == 1) {
      _items.remove(product.id);
    } else {
      _items[product.id] = current.copyWith(quantity: current.quantity - 1);
    }
    notifyListeners();
  }

  void remove(Product product) {
    _items.remove(product.id);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}
