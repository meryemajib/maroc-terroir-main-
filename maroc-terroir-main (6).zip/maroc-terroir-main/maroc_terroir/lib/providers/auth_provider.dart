import 'package:flutter/foundation.dart';

import '../services/api_service.dart';

class AppUser {
  const AppUser({required this.name, required this.email});
  final String name;
  final String email;
}

class OrderRecord {
  const OrderRecord({
    required this.reference,
    required this.date,
    required this.total,
    required this.itemCount,
  });
  final String reference;
  final DateTime date;
  final int total;
  final int itemCount;
}

/// Authentication + order history. Calls the Spring Boot backend when reachable
/// and falls back to a local mock so the app stays usable offline.
class AuthProvider extends ChangeNotifier {
  AppUser? _user;
  final List<OrderRecord> _orders = [];
  final _api = const ApiService();

  AppUser? get user => _user;
  bool get isAuthenticated => _user != null;
  List<OrderRecord> get orders => List.unmodifiable(_orders);

  Future<void> login(String email, String password) async {
    try {
      final data = await _api.login(email, password);
      final name = (data['name'] as String?) ?? email.split('@').first;
      _user = AppUser(name: name, email: email);
    } catch (_) {
      _user = AppUser(name: email.split('@').first, email: email);
    }
    notifyListeners();
  }

  Future<void> register(String name, String email, String password) async {
    try {
      await _api.register(name, email, password);
    } catch (_) {
      // Fall back to local session.
    }
    _user = AppUser(name: name, email: email);
    notifyListeners();
  }

  void logout() {
    _user = null;
    notifyListeners();
  }

  void addOrder(OrderRecord order) {
    _orders.insert(0, order);
    notifyListeners();
  }
}
