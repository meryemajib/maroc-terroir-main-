import 'package:flutter/foundation.dart';

/// Favorites (wishlist) held in memory, mirroring the website's client store.
class FavoritesProvider extends ChangeNotifier {
  final Set<String> _ids = {};

  Set<String> get ids => Set.unmodifiable(_ids);
  bool get isEmpty => _ids.isEmpty;
  int get count => _ids.length;

  bool contains(String productId) => _ids.contains(productId);

  void toggle(String productId) {
    if (!_ids.remove(productId)) _ids.add(productId);
    notifyListeners();
  }
}
