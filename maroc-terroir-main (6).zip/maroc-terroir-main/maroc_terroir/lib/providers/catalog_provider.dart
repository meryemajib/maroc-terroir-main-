import 'package:flutter/foundation.dart';

import '../models/product.dart';
import '../services/catalog_service.dart';

class CatalogProvider extends ChangeNotifier {
  String _category = 'Tous';
  String _query = '';

  String get category => _category;
  String get query => _query;
  List<String> get categories => CatalogService.categories;

  List<Product> get products {
    return CatalogService.products.where((product) {
      final matchesCategory = _category == 'Tous' || product.category == _category;
      final value = _query.toLowerCase();
      final matchesQuery = product.name.toLowerCase().contains(value) ||
          product.origin.toLowerCase().contains(value);
      return matchesCategory && matchesQuery;
    }).toList(growable: false);
  }

  void selectCategory(String value) {
    _category = value;
    notifyListeners();
  }

  void search(String value) {
    _query = value;
    notifyListeners();
  }
}
