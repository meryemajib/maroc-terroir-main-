# Nabta Market

Flutter source project for a Moroccan terroir marketplace. It includes a home storefront, searchable catalog, producer directory, shopping cart, and a checkout confirmation flow.

## Project layout

- `lib/models` - product, producer and cart data types
- `lib/services` - local catalog seed data
- `lib/providers` - cart and catalog state
- `lib/widgets` - reusable app interface components
- `lib/screens` - application pages
- `lib/routing` - named route definitions
- `assets/images` - product photography from the supplied website

The project is source-only and has not been run or built.
