import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { api, setToken } from "@/lib/api";

export interface User {
  name: string;
  email: string;
}

interface AuthCtx {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const Ctx = createContext<AuthCtx | null>(null);
const KEY = "nabta_user";
const DB = "nabta_accounts";

type Account = { name: string; email: string; password: string };

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, []);

  const accounts = (): Account[] => {
    try {
      return JSON.parse(localStorage.getItem(DB) || "[]");
    } catch {
      return [];
    }
  };
  const saveAccounts = (a: Account[]) => localStorage.setItem(DB, JSON.stringify(a));
  const persist = (u: User | null) => {
    setUser(u);
    if (u) localStorage.setItem(KEY, JSON.stringify(u));
    else localStorage.removeItem(KEY);
  };

  // Local mock fallback (used when the backend is unreachable).
  const localLogin = (email: string, password: string) => {
    const acc = accounts().find((a) => a.email === email && a.password === password);
    if (acc) {
      persist({ name: acc.name, email: acc.email });
      return true;
    }
    if (email.includes("@") && password.length >= 4) {
      persist({ name: email.split("@")[0], email });
      return true;
    }
    return false;
  };

  const localRegister = (name: string, email: string, password: string) => {
    if (!name || !email.includes("@") || password.length < 4) return false;
    const all = accounts();
    if (!all.find((a) => a.email === email)) {
      all.push({ name, email, password });
      saveAccounts(all);
    }
    persist({ name, email });
    return true;
  };

  const login = async (email: string, password: string) => {
    try {
      const res = await api.login(email, password);
      setToken(res.token);
      persist({ name: res.name, email: res.email });
      return true;
    } catch (err) {
      // Invalid credentials returned by a reachable backend -> real failure.
      if ((err as { status?: number }).status) return false;
      // Network error / backend offline -> fall back to local mock.
      return localLogin(email, password);
    }
  };

  const register = async (name: string, email: string, password: string) => {
    try {
      const res = await api.register(name, email, password);
      setToken(res.token);
      persist({ name: res.name, email: res.email });
      return true;
    } catch (err) {
      if ((err as { status?: number }).status) return false;
      return localRegister(name, email, password);
    }
  };

  const logout = () => {
    setToken(null);
    persist(null);
  };

  return (
    <Ctx.Provider value={{ user, login, register, logout }}>{children}</Ctx.Provider>
  );
}

export const useAuth = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be used within AuthProvider");
  return c;
};
