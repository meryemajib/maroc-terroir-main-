import { useState, type ImgHTMLAttributes } from "react";

const FALLBACK =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='800' height='800'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='%23dfe9d6'/><stop offset='1' stop-color='%23c4d3b0'/></linearGradient></defs><rect width='100%' height='100%' fill='url(%23g)'/></svg>`,
  );

export function Img({ src, alt, ...rest }: ImgHTMLAttributes<HTMLImageElement>) {
  const [err, setErr] = useState(false);
  return (
    <img
      src={err ? FALLBACK : src}
      alt={alt}
      loading="lazy"
      onError={() => setErr(true)}
      {...rest}
    />
  );
}
