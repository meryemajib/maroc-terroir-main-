import { Link } from "@tanstack/react-router";

export function Footer() {
  const cols = [
    {
      title: "Nabta Market",
      links: ["À propos", "Contact", "FAQ", "Conditions générales", "Politique de confidentialité"],
    },
    { title: "Explorer", links: ["Produits", "Producteurs", "Catégories", "Régions"] },
    { title: "Services", links: ["Livraison", "Circuits courts", "Devenir producteur", "Cartes cadeaux"] },
  ];

  return (
    <footer className="mt-20 border-t border-border bg-cream">
      <div className="container-px mx-auto max-w-7xl py-14">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-primary font-display text-lg font-bold text-primary-foreground">
                N
              </span>
              <span className="font-display text-xl font-bold">Nabta Market</span>
            </div>
            <p className="mt-4 max-w-xs text-sm text-muted-foreground">
              La marketplace qui relie directement les producteurs marocains aux gourmets,
              pour une agriculture durable et locale.
            </p>
            <div className="mt-5 flex gap-2">
              {["Instagram", "Facebook", "LinkedIn"].map((s) => (
                <span
                  key={s}
                  className="rounded-full border border-border bg-background px-3 py-1 text-xs font-medium text-muted-foreground"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>

          {cols.map((c) => (
            <div key={c.title}>
              <h4 className="text-sm font-semibold uppercase tracking-wide text-foreground">
                {c.title}
              </h4>
              <ul className="mt-4 space-y-2.5">
                {c.links.map((l) => (
                  <li key={l}>
                    <Link
                      to="/"
                      className="text-sm text-muted-foreground transition-colors hover:text-primary"
                    >
                      {l}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-border pt-6 sm:flex-row sm:items-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Nabta Market. Tous droits réservés.
          </p>
          <div className="flex gap-3">
            <span className="rounded-lg bg-foreground px-4 py-2 text-xs font-medium text-background">
              App Store
            </span>
            <span className="rounded-lg bg-foreground px-4 py-2 text-xs font-medium text-background">
              Google Play
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
