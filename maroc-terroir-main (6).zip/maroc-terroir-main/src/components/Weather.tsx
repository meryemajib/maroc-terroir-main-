import { forecastFor } from "@/data/catalog";

export function Weather({ base, region }: { base: number; region: string }) {
  const days = forecastFor(base);
  const today = days[0];
  return (
    <div className="rounded-2xl border border-border bg-gradient-to-br from-primary/10 to-accent/30 p-6 shadow-soft">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Météo · {region}</p>
          <p className="font-display text-4xl font-bold">{today.temp}°C</p>
          <p className="text-sm font-medium text-foreground">{today.condition}</p>
        </div>
        <div className="grid h-16 w-16 place-items-center rounded-full bg-background/70 text-2xl font-bold text-primary">
          {today.temp}°
        </div>
      </div>
      <div className="mt-5 grid grid-cols-6 gap-2">
        {days.map((d) => (
          <div key={d.day} className="rounded-xl bg-background/60 px-1 py-3 text-center">
            <p className="text-xs font-medium text-muted-foreground">{d.day}</p>
            <p className="mt-1 text-sm font-bold">{d.temp}°</p>
          </div>
        ))}
      </div>
    </div>
  );
}
