export function FarmMap({
  lat,
  lng,
  label,
}: {
  lat: number;
  lng: number;
  label: string;
}) {
  const d = 0.06;
  const bbox = `${lng - d}%2C${lat - d}%2C${lng + d}%2C${lat + d}`;
  const src = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat}%2C${lng}`;
  return (
    <div className="overflow-hidden rounded-2xl border border-border shadow-soft">
      <iframe
        title={`Localisation de ${label}`}
        src={src}
        className="h-72 w-full"
        loading="lazy"
      />
      <div className="flex items-center justify-between bg-card px-4 py-3 text-sm">
        <span className="font-medium">{label}</span>
        <a
          href={`https://www.openstreetmap.org/?mlat=${lat}&mlon=${lng}#map=12/${lat}/${lng}`}
          target="_blank"
          rel="noreferrer"
          className="font-semibold text-primary hover:underline"
        >
          Ouvrir la carte
        </a>
      </div>
    </div>
  );
}
