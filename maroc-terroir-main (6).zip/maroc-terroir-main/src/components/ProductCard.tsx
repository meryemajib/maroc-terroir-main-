import { Link } from "@tanstack/react-router";
import { type Product, img, producerById } from "@/data/catalog";
import { useCart } from "@/context/CartContext";
import { Img } from "./Img";

export function ProductCard({ product, large = false }: { product: Product; large?: boolean }) {
  const { add } = useCart();
  const producer = producerById(product.producerId);

  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift">
      <Link
        to="/product/$id"
        params={{ id: product.id }}
        className="relative block overflow-hidden"
      >
        <Img
          src={img(product.image, large ? 900 : 600)}
          alt={product.name}
          className={`w-full ${large ? "h-64" : "h-48"} object-cover transition-transform duration-500 group-hover:scale-105`}
        />
        <span className="absolute left-3 top-3 rounded-full bg-background/90 px-3 py-1 text-xs font-medium text-foreground backdrop-blur">
          {product.category}
        </span>
        {product.bio && (
          <span className="absolute right-3 top-3 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
            BIO
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col p-4">
        <Link to="/product/$id" params={{ id: product.id }}>
          <h3 className="text-lg font-semibold leading-tight hover:text-primary">
            {product.name}
          </h3>
        </Link>
        <p className="mt-0.5 text-sm text-muted-foreground">{product.unit}</p>
        {producer && (
          <Link
            to="/producer/$id"
            params={{ id: producer.id }}
            className="mt-1 text-sm text-primary-dark hover:underline"
          >
            {producer.name} · {producer.city}
          </Link>
        )}
        {large && (
          <p className="mt-2 text-xs text-muted-foreground">{product.delivery}</p>
        )}

        <div className="mt-auto flex items-center justify-between pt-4">
          <span className="text-xl font-bold text-foreground">
            {product.price} <span className="text-sm font-medium text-muted-foreground">DH</span>
          </span>
          <button
            onClick={() => add(product.id)}
            className="rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary-dark"
          >
            Ajouter
          </button>
        </div>
      </div>
    </div>
  );
}
