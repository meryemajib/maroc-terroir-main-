import { Link } from "@tanstack/react-router";
import { type Producer, img, productsByProducer } from "@/data/catalog";
import { Img } from "./Img";

export function ProducerCard({ producer }: { producer: Producer }) {
  const count = productsByProducer(producer.id).length;
  return (
    <Link
      to="/producer/$id"
      params={{ id: producer.id }}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift"
    >
      <div className="relative h-40 overflow-hidden">
        <Img
          src={img(producer.cover, 700)}
          alt={`Ferme de ${producer.name}`}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute -bottom-8 left-5 h-16 w-16 overflow-hidden rounded-full border-4 border-card shadow-card">
          <Img src={img(producer.portrait, 200)} alt={producer.name} className="h-full w-full object-cover" />
        </div>
      </div>
      <div className="flex flex-1 flex-col p-5 pt-10">
        <h3 className="text-lg font-semibold">{producer.name}</h3>
        <p className="text-sm text-primary-dark">{producer.city} · {producer.region}</p>
        <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{producer.bio}</p>
        <div className="mt-auto flex items-center justify-between pt-4 text-sm">
          <span className="font-medium text-foreground">{count} produits</span>
          <span className="font-semibold text-primary group-hover:underline">Voir le profil →</span>
        </div>
      </div>
    </Link>
  );
}
