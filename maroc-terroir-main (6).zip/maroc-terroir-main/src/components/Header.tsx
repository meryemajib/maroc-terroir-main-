import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";

export function Header() {
  const { count } = useCart();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate({ to: "/search", search: { q: q || undefined, cat: undefined, region: undefined } });
  };

  const nav = [
    { to: "/", label: "Accueil" },
    { to: "/search", label: "Produits" },
    { to: "/producers", label: "Producteurs" },
    { to: "/a-propos", label: "Notre Histoire" },
    { to: "/contact", label: "Contact" },
  ] as const;

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="container-px mx-auto flex h-16 max-w-7xl items-center gap-4">
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-primary font-display text-lg font-bold text-primary-foreground">
            N
          </span>
          <span className="font-display text-xl font-bold tracking-tight">Nabta Market</span>
        </Link>

        <nav className="ml-4 hidden items-center gap-1 md:flex">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              search={n.to === "/search" ? { q: undefined, cat: undefined, region: undefined } : undefined}
              activeOptions={{ exact: n.to === "/" }}
              activeProps={{ className: "text-primary" }}
              className="rounded-full px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:text-primary"
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <form onSubmit={submit} className="ml-auto hidden flex-1 max-w-xs lg:block">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Rechercher un produit…"
            className="w-full rounded-full border border-border bg-secondary/60 px-4 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
          />
        </form>

        <div className="ml-auto flex items-center gap-2 lg:ml-2">
          {user ? (
            <div className="hidden items-center gap-2 sm:flex">
              <span className="text-sm font-medium">Bonjour, {user.name}</span>
              <button onClick={logout} className="text-sm text-muted-foreground hover:text-primary">
                Déconnexion
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              search={{ redirect: undefined }}
              className="hidden rounded-full px-4 py-2 text-sm font-medium hover:text-primary sm:block"
            >
              Connexion
            </Link>
          )}

          <Link
            to="/cart"
            className="relative rounded-full bg-secondary px-4 py-2 text-sm font-semibold transition-colors hover:bg-accent"
          >
            Panier
            {count > 0 && (
              <span className="absolute -right-1 -top-1 grid h-5 w-5 place-items-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                {count}
              </span>
            )}
          </Link>

          <button
            onClick={() => setOpen((o) => !o)}
            className="rounded-full bg-secondary px-3 py-2 text-sm md:hidden"
            aria-label="Menu"
          >
            ☰
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-border bg-background md:hidden">
          <div className="container-px mx-auto flex max-w-7xl flex-col gap-1 py-3">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                search={n.to === "/search" ? { q: undefined, cat: undefined, region: undefined } : undefined}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-secondary"
              >
                {n.label}
              </Link>
            ))}
            {!user && (
              <Link
                to="/login"
                search={{ redirect: undefined }}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-secondary"
              >
                Connexion
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
