// Nabta Market — REST client for the Spring Boot backend.
//
// Configure the backend origin with VITE_API_URL (e.g. http://localhost:8080).
// When the backend is unreachable (e.g. inside the Lovable preview where the
// Java server isn't running), calls throw and callers fall back to the local
// mock catalog / localStorage so the UI keeps working exactly as before.

export const API_BASE =
  (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, "") ||
  "http://localhost:8080";

const API = `${API_BASE}/api`;

const TOKEN_KEY = "nabta_token";

export const getToken = (): string | null => {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
};

export const setToken = (token: string | null) => {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore */
  }
};

/** Whether an API base is configured to attempt real backend calls. */
export const apiEnabled = Boolean(import.meta.env.VITE_API_URL);

interface ReqOptions {
  method?: string;
  body?: unknown;
  auth?: boolean;
  signal?: AbortSignal;
}

async function request<T>(path: string, opts: ReqOptions = {}): Promise<T> {
  const headers: Record<string, string> = {};
  if (opts.body !== undefined) headers["Content-Type"] = "application/json";
  if (opts.auth) {
    const token = getToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${API}${path}`, {
    method: opts.method ?? "GET",
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    signal: opts.signal,
  });

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      message = (data?.message as string) || (data?.error as string) || message;
    } catch {
      /* ignore body parse errors */
    }
    const err = new Error(message) as Error & { status?: number };
    err.status = res.status;
    throw err;
  }

  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

// ---- Auth ----
export interface AuthResponse {
  token: string;
  name: string;
  email: string;
  role: string;
}

export const api = {
  // Auth
  login: (email: string, password: string) =>
    request<AuthResponse>("/auth/login", { method: "POST", body: { email, password } }),
  register: (name: string, email: string, password: string) =>
    request<AuthResponse>("/auth/register", { method: "POST", body: { name, email, password } }),
  me: () => request<AuthResponse>("/auth/me", { auth: true }),

  // Products
  products: (params?: { category?: string; producerId?: string; q?: string }) => {
    const qs = new URLSearchParams();
    if (params?.category) qs.set("category", params.category);
    if (params?.producerId) qs.set("producerId", params.producerId);
    if (params?.q) qs.set("q", params.q);
    const suffix = qs.toString() ? `?${qs}` : "";
    return request<unknown[]>(`/products${suffix}`);
  },
  product: (id: string) => request<unknown>(`/products/${id}`),
  featured: () => request<unknown[]>("/products/featured"),
  demanded: () => request<unknown[]>("/products/demanded"),
  pioneer: () => request<unknown[]>("/products/pioneer"),

  // Producers
  producers: (region?: string) =>
    request<unknown[]>(`/producers${region ? `?region=${encodeURIComponent(region)}` : ""}`),
  producer: (id: string) => request<unknown>(`/producers/${id}`),
  producerProducts: (id: string) => request<unknown[]>(`/producers/${id}/products`),

  // Orders
  createOrder: (order: {
    customerName: string;
    phone: string;
    address: string;
    city?: string;
    userEmail?: string;
    items: { productId: string; qty: number }[];
  }) => request<unknown>("/orders", { method: "POST", body: order, auth: true }),

  // Contact
  contact: (msg: {
    fullName: string;
    email: string;
    phone?: string;
    subject: string;
    message: string;
  }) => request<unknown>("/contact", { method: "POST", body: msg }),
};
