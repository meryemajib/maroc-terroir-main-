// Central catalog: producers + products with real photography.
import figImg from "@/assets/produce/fig.jpg";
import dateImg from "@/assets/produce/date.jpg";
import honeyImg from "@/assets/produce/honey.jpg";
import grapeImg from "@/assets/produce/grape.jpg";
import peachImg from "@/assets/produce/peach.jpg";
import pumpkinImg from "@/assets/produce/pumpkin.jpg";
import plumImg from "@/assets/produce/plum.jpg";
import olivesImg from "@/assets/produce/olives.jpg";
import harvestImg from "@/assets/produce/harvest.jpg";

// Locally generated, subject-accurate photos override remote URLs.
const LOCAL: Partial<Record<string, string>> = {
  fig: figImg,
  date: dateImg,
  honey: honeyImg,
  grape: grapeImg,
  peach: peachImg,
  pumpkin: pumpkinImg,
  plum: plumImg,
  olives: olivesImg,
  harvest: harvestImg,
};

const u = (id: string, w = 800) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;


// Curated, topical Unsplash photo IDs
export const IMG = {
  // produce
  tomato: "1592924357228-91a4daadcfea",
  potato: "1518977676601-b53f82aba655",
  onion: "1620574387735-3624d75b2dbc",
  carrot: "1598170845058-32b9d6a5da37",
  lemon: "1590502593747-42a996133562",
  orange: "1547514701-42782101795e",
  zucchini: "1583687355032-89b902b7335f",
  pepper: "1563565375-f3fdfdbefa83",
  eggplant: "1659261200833-ec8761558af7",
  cucumber: "1604977042946-1eecc30f269e",
  garlic: "1540148426945-6cf22a6b2383",
  cabbage: "1594282486552-05b4d80fbb9f",
  broccoli: "1459411621453-7b03977f4bfc",
  spinach: "1576045057995-568f588f82fb",
  peas: "1587735243615-c03f25aaff15",
  beet: "1593105544559-ecb03bf76f82",
  pumpkin: "1570586437263-ab629fccc838",
  turnip: "1518977822534-7049a61ee0c2",
  lettuce: "1622206151226-18ca2c9ab4a1",
  cauliflower: "1568584711271-6c929fb49b60",
  apple: "1568702846914-96b305d2aaeb",
  banana: "1571771894821-ce9b6c11b08e",
  strawberry: "1543528176-61b239494933",
  grape: "1599819177626-b50f9e9be0e6",
  fig: "1601379329542-31c59c5a8d99",
  pomegranate: "1541344999736-83eca272f6fc",
  watermelon: "1587049352846-4a222e784d38",
  melon: "1571575173700-afb9492e6a50",
  peach: "1629828874514-d71ba886a6f6",
  apricot: "1560806887-1e4cd0b6cbd6",
  cherry: "1528821128474-27f963b062bf",
  plum: "1602532305019-3beb4b6dc1e6",
  kiwi: "1585059895524-72359e06133a",
  pear: "1514756331096-242fdeb70d4a",
  mango: "1605027990121-cbae9e0642df",
  avocado: "1523049673857-eb18f1d7b578",
  almond: "1508061253366-f7da158b6d46",
  date: "1609040146481-7c9f59baba62",
  // artisanal
  oliveoil: "1474979266404-7eaacbcd87c5",
  honey: "1587049352846-4a222e784d38",
  olives: "1611171711791-b34fa425e1aa",
  cheese: "1486297678162-eb2a19b0a32d",
  milk: "1563636619-e9143da7973b",
  argan: "1608571423902-eed4a5ad8108",
  // scenery
  heroFarm: "1500382017468-9049fed747ef",
  farm1: "1444858291040-58f756a3bdd6",
  farm2: "1605000797499-95a51c5269ae",
  farm3: "1592982537447-7440770cbfc9",
  field: "1464226184884-fa280b87c399",
  orchard: "1568702846914-96b305d2aaeb",
  greenhouse: "1416879595882-3373a0480b5b",
  harvest: "1530507629858-e3759c1d3e0d",
  // farmers
  farmer1: "1507003211169-0a1dd7228f2d",
  farmer2: "1494790108377-be9c29b29330",
  farmer3: "1500648767791-00dcc994a43e",
  farmer4: "1438761681033-6461ffad8d80",
  farmer5: "1472099645785-5658abf4ff4e",
  farmer6: "1544005313-94ddf0286df2",
  farmer7: "1519345182560-3f2917c472ef",
  farmer8: "1547425260-76bcadfb4f2c",
  farmer9: "1573497019940-1c28c88b4f3e",
  farmer10: "1607990281513-2c110a25bd8c",
};

export type ImgKey = keyof typeof IMG;
export const img = (key: ImgKey, w = 800) => LOCAL[key as string] ?? u(IMG[key], w);

export type Category =
  | "Légumes"
  | "Fruits"
  | "Huile d'olive"
  | "Miel"
  | "Produits laitiers"
  | "Fruits secs";

export interface Producer {
  id: string;
  name: string;
  city: string;
  region: string;
  experience: number;
  farmSize: string;
  productionType: string;
  portrait: keyof typeof IMG;
  cover: keyof typeof IMG;
  bio: string;
  story: string;
  philosophy: string;
  gallery: (keyof typeof IMG)[];
  lat: number;
  lng: number;
  weatherBase: number;
}

export interface Product {
  id: string;
  name: string;
  unit: string;
  price: number;
  category: Category;
  producerId: string;
  image: keyof typeof IMG;
  origin: string;
  description: string;
  delivery: string;
  bio?: boolean;
  featured?: boolean;
  pioneer?: boolean;
  demanded?: boolean;
}

export const producers: Producer[] = [
  {
    id: "ahmed-benali",
    name: "Ahmed Benali",
    city: "Meknès",
    region: "Fès-Meknès",
    experience: 24,
    farmSize: "18 hectares",
    productionType: "Agriculture biologique",
    portrait: "farmer1",
    cover: "farm1",
    bio: "Producteur d'olives et d'huile d'olive vierge extra dans les plaines fertiles de Meknès.",
    story:
      "Ahmed a repris l'oliveraie familiale il y a plus de deux décennies. Sur les terres rouges du Saïs, il cultive des oliviers centenaires selon des méthodes transmises de génération en génération, en respectant le rythme naturel des saisons.",
    philosophy:
      "« La terre nous donne exactement ce qu'on lui offre. » Ahmed refuse tout pesticide de synthèse et pratique une irrigation raisonnée goutte-à-goutte.",
    gallery: ["farm1", "oliveoil", "olives", "field"],
    lat: 33.8956,
    lng: -5.5547,
    weatherBase: 22,
  },
  {
    id: "fatima-zahra",
    name: "Fatima Zahra",
    city: "Agadir",
    region: "Souss-Massa",
    experience: 16,
    farmSize: "9 hectares",
    productionType: "Agriculture durable",
    portrait: "farmer2",
    cover: "greenhouse",
    bio: "Spécialiste des agrumes et des tomates sous le soleil généreux du Souss.",
    story:
      "Fatima dirige une exploitation maraîchère moderne près d'Agadir. Pionnière de la culture sous serre raisonnée, elle emploie une dizaine de femmes de sa région et défend une agriculture à taille humaine.",
    philosophy:
      "Elle privilégie les variétés locales adaptées au climat et la lutte biologique contre les nuisibles.",
    gallery: ["greenhouse", "tomato", "orange", "harvest"],
    lat: 30.4278,
    lng: -9.5981,
    weatherBase: 25,
  },
  {
    id: "hassan-el-idrissi",
    name: "Hassan El Idrissi",
    city: "Taroudant",
    region: "Souss-Massa",
    experience: 30,
    farmSize: "12 hectares",
    productionType: "Agriculture biologique",
    portrait: "farmer3",
    cover: "argan",
    bio: "Gardien des arganiers et producteur d'amandes et d'huile d'argan.",
    story:
      "Au cœur de l'arganeraie, Hassan perpétue un savoir-faire ancestral. Il travaille main dans la main avec une coopérative féminine pour produire une huile d'argan d'exception.",
    philosophy:
      "Préserver l'arganier, arbre emblématique du Maroc, est au centre de chacune de ses décisions.",
    gallery: ["argan", "almond", "field", "farm2"],
    lat: 30.4703,
    lng: -8.8769,
    weatherBase: 26,
  },
  {
    id: "youssef-amrani",
    name: "Youssef Amrani",
    city: "Marrakech",
    region: "Marrakech-Safi",
    experience: 12,
    farmSize: "7 hectares",
    productionType: "Agriculture durable",
    portrait: "farmer4",
    cover: "orchard",
    bio: "Arboriculteur passionné de grenades, figues et abricots.",
    story:
      "Jeune ingénieur agronome revenu à la terre, Youssef a planté des vergers diversifiés au pied de l'Atlas. Il mise sur l'agroécologie et les circuits courts.",
    philosophy:
      "« Vendre directement, sans intermédiaire, c'est rendre justice au travail du paysan. »",
    gallery: ["orchard", "pomegranate", "fig", "apricot"],
    lat: 31.6295,
    lng: -7.9811,
    weatherBase: 27,
  },
  {
    id: "khadija-tazi",
    name: "Khadija Tazi",
    city: "Béni Mellal",
    region: "Béni Mellal-Khénifra",
    experience: 19,
    farmSize: "15 hectares",
    productionType: "Agriculture biologique",
    portrait: "farmer5",
    cover: "field",
    bio: "Maraîchère bio et productrice d'agrumes au pied du Moyen Atlas.",
    story:
      "Khadija a converti l'exploitation familiale au bio en 2010. Elle cultive une grande diversité de légumes de saison pour les marchés de la région.",
    philosophy: "La rotation des cultures et le compost maison sont ses meilleurs alliés.",
    gallery: ["field", "carrot", "lemon", "harvest"],
    lat: 32.3373,
    lng: -6.3498,
    weatherBase: 23,
  },
  {
    id: "rachid-bennani",
    name: "Rachid Bennani",
    city: "Khénifra",
    region: "Béni Mellal-Khénifra",
    experience: 28,
    farmSize: "Apiculture nomade",
    productionType: "Apiculture naturelle",
    portrait: "farmer6",
    cover: "farm3",
    bio: "Apiculteur de montagne, producteur de miels naturels du Moyen Atlas.",
    story:
      "Rachid déplace ses ruches au gré des floraisons, du thym sauvage à l'eucalyptus. Un miel récolté à la main, jamais chauffé.",
    philosophy: "Respecter l'abeille, c'est respecter tout l'écosystème de la montagne.",
    gallery: ["farm3", "honey", "field", "orchard"],
    lat: 32.9394,
    lng: -5.6685,
    weatherBase: 18,
  },
  {
    id: "nadia-bouzidi",
    name: "Nadia Bouzidi",
    city: "El Jadida",
    region: "Casablanca-Settat",
    experience: 14,
    farmSize: "11 hectares",
    productionType: "Agriculture durable",
    portrait: "farmer7",
    cover: "farm2",
    bio: "Productrice laitière fermière sur la côte atlantique.",
    story:
      "Nadia élève un troupeau de vaches en plein air et transforme le lait à la ferme en fromages frais et beurre artisanal.",
    philosophy: "Le bien-être animal d'abord : pâturage libre et alimentation naturelle.",
    gallery: ["farm2", "cheese", "milk", "field"],
    lat: 33.2316,
    lng: -8.5007,
    weatherBase: 21,
  },
  {
    id: "omar-fassi",
    name: "Omar Fassi",
    city: "Berkane",
    region: "Oriental",
    experience: 22,
    farmSize: "20 hectares",
    productionType: "Agriculture biologique",
    portrait: "farmer8",
    cover: "orchard",
    bio: "Roi des agrumes de Berkane, célèbre pour ses clémentines et oranges.",
    story:
      "Omar cultive les fameux agrumes de Berkane, une région labellisée. Ses vergers s'étendent le long de la Moulouya.",
    philosophy: "La qualité avant la quantité : chaque fruit est cueilli à pleine maturité.",
    gallery: ["orchard", "orange", "lemon", "harvest"],
    lat: 34.92,
    lng: -2.32,
    weatherBase: 24,
  },
  {
    id: "salma-ouazzani",
    name: "Salma Ouazzani",
    city: "Chefchaouen",
    region: "Tanger-Tétouan-Al Hoceïma",
    experience: 10,
    farmSize: "5 hectares",
    productionType: "Agriculture de montagne",
    portrait: "farmer9",
    cover: "field",
    bio: "Cultive légumes anciens et plantes aromatiques dans le Rif.",
    story:
      "Sur les terrasses verdoyantes du Rif, Salma fait revivre des variétés anciennes oubliées et des herbes aromatiques de montagne.",
    philosophy: "Sauvegarder la biodiversité paysanne, semence après semence.",
    gallery: ["field", "spinach", "pepper", "farm1"],
    lat: 35.1688,
    lng: -5.2636,
    weatherBase: 17,
  },
  {
    id: "brahim-sahli",
    name: "Brahim Sahli",
    city: "Errachidia",
    region: "Drâa-Tafilalet",
    experience: 35,
    farmSize: "Palmeraie 14 ha",
    productionType: "Agriculture oasienne",
    portrait: "farmer10",
    cover: "farm3",
    bio: "Maître phoeniciculteur, producteur de dattes Majhoul du Tafilalet.",
    story:
      "Dans la palmeraie ancestrale du Tafilalet, Brahim cultive les dattes les plus prisées du Maroc selon le système oasien millénaire des trois étages.",
    philosophy: "L'oasis est un trésor fragile que chaque génération doit transmettre intact.",
    gallery: ["farm3", "date", "field", "harvest"],
    lat: 31.9314,
    lng: -4.4244,
    weatherBase: 28,
  },
];

export const producerById = (id: string) => producers.find((p) => p.id === id);

// ---- Products ----
let pid = 0;
const mk = (p: Omit<Product, "id">): Product => ({ id: `p${++pid}`, ...p });

const D = "Livraison 48h • Cueilli à la commande";

export const products: Product[] = [
  // 20 légumes
  mk({ name: "Pommes de terre", unit: "1 kg", price: 6, category: "Légumes", producerId: "khadija-tazi", image: "potato", origin: "Béni Mellal", description: "Pommes de terre à chair ferme, idéales pour toutes vos préparations.", delivery: D }),
  mk({ name: "Oignons", unit: "1 kg", price: 5, category: "Légumes", producerId: "khadija-tazi", image: "onion", origin: "Béni Mellal", description: "Oignons jaunes savoureux, récoltés à pleine maturité.", delivery: D }),
  mk({ name: "Tomates", unit: "1 kg", price: 8, category: "Légumes", producerId: "fatima-zahra", image: "tomato", origin: "Agadir", description: "Tomates juteuses cultivées sous le soleil du Souss.", delivery: D, demanded: true }),
  mk({ name: "Carottes", unit: "1 kg", price: 7, category: "Légumes", producerId: "khadija-tazi", image: "carrot", origin: "Béni Mellal", description: "Carottes croquantes et sucrées du Moyen Atlas.", delivery: D }),
  mk({ name: "Courgettes", unit: "1 kg", price: 7, category: "Légumes", producerId: "fatima-zahra", image: "zucchini", origin: "Agadir", description: "Courgettes tendres cueillies jeunes.", delivery: D }),
  mk({ name: "Poivrons", unit: "1 kg", price: 12, category: "Légumes", producerId: "fatima-zahra", image: "pepper", origin: "Agadir", description: "Poivrons colorés et charnus.", delivery: D }),
  mk({ name: "Aubergines", unit: "1 kg", price: 9, category: "Légumes", producerId: "salma-ouazzani", image: "eggplant", origin: "Chefchaouen", description: "Aubergines violettes brillantes du Rif.", delivery: D }),
  mk({ name: "Concombres", unit: "1 kg", price: 6, category: "Légumes", producerId: "fatima-zahra", image: "cucumber", origin: "Agadir", description: "Concombres frais et croquants.", delivery: D }),
  mk({ name: "Ail", unit: "500 g", price: 14, category: "Légumes", producerId: "salma-ouazzani", image: "garlic", origin: "Chefchaouen", description: "Ail de montagne parfumé.", delivery: D }),
  mk({ name: "Chou vert", unit: "pièce", price: 8, category: "Légumes", producerId: "salma-ouazzani", image: "cabbage", origin: "Chefchaouen", description: "Chou frais récolté du jour.", delivery: D }),
  mk({ name: "Brocoli", unit: "500 g", price: 13, category: "Légumes", producerId: "khadija-tazi", image: "broccoli", origin: "Béni Mellal", description: "Brocoli bio riche en saveurs.", delivery: D, bio: true }),
  mk({ name: "Épinards", unit: "500 g", price: 9, category: "Légumes", producerId: "salma-ouazzani", image: "spinach", origin: "Chefchaouen", description: "Épinards frais en bottes.", delivery: D }),
  mk({ name: "Petits pois", unit: "1 kg", price: 15, category: "Légumes", producerId: "khadija-tazi", image: "peas", origin: "Béni Mellal", description: "Petits pois doux à écosser.", delivery: D }),
  mk({ name: "Betteraves", unit: "1 kg", price: 8, category: "Légumes", producerId: "khadija-tazi", image: "beet", origin: "Béni Mellal", description: "Betteraves rouges sucrées.", delivery: D }),
  mk({ name: "Potiron", unit: "1 kg", price: 7, category: "Légumes", producerId: "salma-ouazzani", image: "pumpkin", origin: "Chefchaouen", description: "Potiron à la chair orangée et fondante.", delivery: D }),
  mk({ name: "Navets", unit: "1 kg", price: 6, category: "Légumes", producerId: "khadija-tazi", image: "turnip", origin: "Béni Mellal", description: "Navets tendres de saison.", delivery: D }),
  mk({ name: "Laitue", unit: "pièce", price: 5, category: "Légumes", producerId: "fatima-zahra", image: "lettuce", origin: "Agadir", description: "Laitue fraîche et craquante.", delivery: D }),
  mk({ name: "Chou-fleur", unit: "pièce", price: 10, category: "Légumes", producerId: "salma-ouazzani", image: "cauliflower", origin: "Chefchaouen", description: "Chou-fleur blanc et ferme.", delivery: D }),
  mk({ name: "Tomates cerises", unit: "500 g", price: 11, category: "Légumes", producerId: "fatima-zahra", image: "tomato", origin: "Agadir", description: "Tomates cerises sucrées à croquer.", delivery: D }),
  mk({ name: "Piments verts", unit: "500 g", price: 9, category: "Légumes", producerId: "fatima-zahra", image: "pepper", origin: "Agadir", description: "Piments verts doux et parfumés.", delivery: D }),

  // 18 fruits
  mk({ name: "Citrons", unit: "1 kg", price: 10, category: "Fruits", producerId: "omar-fassi", image: "lemon", origin: "Berkane", description: "Citrons juteux et parfumés de Berkane.", delivery: D, bio: true, demanded: true }),
  mk({ name: "Oranges", unit: "1 kg", price: 9, category: "Fruits", producerId: "omar-fassi", image: "orange", origin: "Berkane", description: "Oranges sucrées gorgées de soleil.", delivery: D, demanded: true }),
  mk({ name: "Oranges BIO", unit: "2 kg", price: 28, category: "Fruits", producerId: "omar-fassi", image: "orange", origin: "Berkane", description: "Oranges certifiées biologiques de Berkane.", delivery: D, bio: true, demanded: true, pioneer: true }),
  mk({ name: "Mangues", unit: "1 kg", price: 35, category: "Fruits", producerId: "youssef-amrani", image: "mango", origin: "Marrakech", description: "Mangues fondantes et parfumées.", delivery: D, demanded: true, featured: true }),
  mk({ name: "Avocats", unit: "1 kg", price: 32, category: "Fruits", producerId: "youssef-amrani", image: "avocado", origin: "Marrakech", description: "Avocats crémeux à point.", delivery: D, demanded: true, featured: true }),
  mk({ name: "Pommes", unit: "1 kg", price: 12, category: "Fruits", producerId: "salma-ouazzani", image: "apple", origin: "Chefchaouen", description: "Pommes croquantes de montagne.", delivery: D }),
  mk({ name: "Bananes", unit: "1 kg", price: 14, category: "Fruits", producerId: "fatima-zahra", image: "banana", origin: "Agadir", description: "Bananes locales sucrées.", delivery: D }),
  mk({ name: "Fraises", unit: "500 g", price: 18, category: "Fruits", producerId: "nadia-bouzidi", image: "strawberry", origin: "El Jadida", description: "Fraises parfumées de la côte.", delivery: D }),
  mk({ name: "Raisin", unit: "1 kg", price: 16, category: "Fruits", producerId: "youssef-amrani", image: "grape", origin: "Marrakech", description: "Raisin de table juteux.", delivery: D }),
  mk({ name: "Figues", unit: "1 kg", price: 22, category: "Fruits", producerId: "youssef-amrani", image: "fig", origin: "Marrakech", description: "Figues fraîches et mielleuses.", delivery: D, featured: true }),
  mk({ name: "Grenades", unit: "1 kg", price: 18, category: "Fruits", producerId: "youssef-amrani", image: "pomegranate", origin: "Marrakech", description: "Grenades aux grains rubis.", delivery: D, featured: true }),
  mk({ name: "Pastèque", unit: "pièce", price: 25, category: "Fruits", producerId: "fatima-zahra", image: "watermelon", origin: "Agadir", description: "Pastèque rafraîchissante et sucrée.", delivery: D }),
  mk({ name: "Melon", unit: "pièce", price: 16, category: "Fruits", producerId: "fatima-zahra", image: "melon", origin: "Agadir", description: "Melon parfumé à chair orangée.", delivery: D }),
  mk({ name: "Pêches", unit: "1 kg", price: 17, category: "Fruits", producerId: "youssef-amrani", image: "peach", origin: "Marrakech", description: "Pêches juteuses de plein été.", delivery: D }),
  mk({ name: "Abricots", unit: "1 kg", price: 19, category: "Fruits", producerId: "youssef-amrani", image: "apricot", origin: "Marrakech", description: "Abricots sucrés cueillis mûrs.", delivery: D, featured: true }),
  mk({ name: "Grenades BIO", unit: "2 kg", price: 38, category: "Fruits", producerId: "youssef-amrani", image: "pomegranate", origin: "Marrakech", description: "Grenades biologiques de l'Atlas.", delivery: D, bio: true, pioneer: true }),
  mk({ name: "Clémentines", unit: "2 kg", price: 24, category: "Fruits", producerId: "omar-fassi", image: "orange", origin: "Berkane", description: "Clémentines sucrées sans pépins.", delivery: D, pioneer: true }),
  mk({ name: "Dattes Majhoul", unit: "500 g", price: 60, category: "Fruits secs", producerId: "brahim-sahli", image: "date", origin: "Errachidia", description: "Dattes Majhoul moelleuses du Tafilalet.", delivery: D, featured: true, demanded: true, pioneer: true }),

  // artisanal / most demanded
  mk({ name: "Huile d'olive vierge extra", unit: "1 L", price: 85, category: "Huile d'olive", producerId: "ahmed-benali", image: "oliveoil", origin: "Meknès", description: "Huile d'olive première pression à froid, fruitée et équilibrée.", delivery: "Livraison 72h • Bouteille verre", bio: true, demanded: true, featured: true, pioneer: true }),
  mk({ name: "Miel naturel de montagne", unit: "500 g", price: 90, category: "Miel", producerId: "rachid-bennani", image: "honey", origin: "Khénifra", description: "Miel cru de thym sauvage, récolté à la main.", delivery: "Livraison 72h • Pot verre", bio: true, demanded: true, featured: true, pioneer: true }),
  mk({ name: "Amandes", unit: "500 g", price: 55, category: "Fruits secs", producerId: "hassan-el-idrissi", image: "almond", origin: "Taroudant", description: "Amandes croquantes de l'arganeraie.", delivery: D, demanded: true, pioneer: true }),
  mk({ name: "Huile d'argan alimentaire", unit: "250 ml", price: 120, category: "Huile d'olive", producerId: "hassan-el-idrissi", image: "argan", origin: "Taroudant", description: "Huile d'argan pure, pressée par une coopérative féminine.", delivery: "Livraison 72h • Bouteille verre", bio: true, featured: true }),
  mk({ name: "Fromage frais fermier", unit: "250 g", price: 35, category: "Produits laitiers", producerId: "nadia-bouzidi", image: "cheese", origin: "El Jadida", description: "Fromage frais artisanal au lait cru.", delivery: "Livraison 48h • Chaîne du froid", featured: true }),
  mk({ name: "Beurre fermier", unit: "250 g", price: 28, category: "Produits laitiers", producerId: "nadia-bouzidi", image: "milk", origin: "El Jadida", description: "Beurre baratté à la ferme.", delivery: "Livraison 48h • Chaîne du froid" }),
  mk({ name: "Olives vertes", unit: "1 kg", price: 30, category: "Huile d'olive", producerId: "ahmed-benali", image: "olives", origin: "Meknès", description: "Olives vertes préparées de façon traditionnelle.", delivery: D }),
];

export const productById = (id: string) => products.find((p) => p.id === id);
export const productsByProducer = (pid: string) => products.filter((p) => p.producerId === pid);

export const categories: Category[] = [
  "Légumes",
  "Fruits",
  "Huile d'olive",
  "Miel",
  "Produits laitiers",
  "Fruits secs",
];

export const regions = [...new Set(producers.map((p) => p.region))];

// Built-in 6-day forecast generator (deterministic per region)
export interface DayWeather {
  day: string;
  temp: number;
  condition: string;
}
const days = ["Auj.", "Demain", "Mer.", "Jeu.", "Ven.", "Sam."];
const conditions = ["Ensoleillé", "Peu nuageux", "Ensoleillé", "Nuageux", "Ensoleillé", "Éclaircies"];
export const forecastFor = (base: number): DayWeather[] =>
  days.map((day, i) => ({
    day,
    temp: base + ((i * 7) % 5) - 2,
    condition: conditions[i % conditions.length],
  }));
