import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { img } from "@/data/catalog";
import { Img } from "@/components/Img";

interface S {
  redirect?: string;
}

export const Route = createFileRoute("/register")({
  validateSearch: (s: Record<string, unknown>): S => ({
    redirect: typeof s.redirect === "string" ? s.redirect : undefined,
  }),
  head: () => ({ meta: [{ title: "Créer un compte — Nabta Market" }] }),
  component: RegisterPage,
});

function RegisterPage() {
  const { redirect } = Route.useSearch();
  const { register } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (await register(name, email, password)) {
      navigate({ to: redirect || "/" });
    } else {
      setError("Veuillez renseigner un nom, un e-mail valide et un mot de passe d'au moins 4 caractères.");
    }
  };

  return (
    <div className="grid min-h-[calc(100vh-4rem)] lg:grid-cols-2">
      <div className="container-px order-2 flex items-center justify-center bg-cream py-16 lg:order-1">
        <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 shadow-card">
          <h1 className="text-3xl font-bold">Créer un compte</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Rejoignez la communauté Nabta Market et soutenez les producteurs marocains.
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium">Nom complet</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Votre nom"
                className="w-full rounded-xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium">E-mail</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="vous@exemple.com"
                className="w-full rounded-xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium">Mot de passe</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}

            <button className="w-full rounded-full bg-primary py-3.5 font-semibold text-primary-foreground shadow-lift transition-transform hover:scale-[1.02]">
              S'inscrire
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Déjà inscrit ?{" "}
            <Link to="/login" search={{ redirect }} className="font-semibold text-primary hover:underline">
              Se connecter
            </Link>
          </p>
        </div>
      </div>

      <div className="relative order-1 hidden lg:order-2 lg:block">
        <Img src={img("harvest", 1200)} alt="Récolte au Maroc" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-primary-dark/40" />
        <div className="absolute bottom-10 right-10 max-w-sm text-right text-background">
          <h2 className="font-display text-3xl font-bold">Du champ à votre table.</h2>
          <p className="mt-2 text-background/90">Des produits frais, une rémunération juste pour les producteurs.</p>
        </div>
      </div>
    </div>
  );
}
