import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { img } from "@/data/catalog";
import { Img } from "@/components/Img";

export const Route = createFileRoute("/a-propos")({
  head: () => ({
    meta: [
      { title: "À Propos de Nous — Notre Histoire | Nabta Market" },
      {
        name: "description",
        content:
          "Nabta Market est une solution pour l'agriculture créée avec les agriculteurs marocains : circuits courts, juste rémunération et produits frais en direct des fermes.",
      },
      { property: "og:title", content: "Notre Histoire — Nabta Market" },
      {
        property: "og:description",
        content:
          "Découvrez pourquoi Nabta Market connecte directement producteurs et consommateurs pour soutenir l'agriculture marocaine.",
      },
      { property: "og:image", content: img("heroFarm", 1200) },
    ],
  }),
  component: About,
});

function useCountUp(target: number, run: boolean, duration = 1600) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!run) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(eased * target));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, run, duration]);
  return val;
}

function Stat({ value, suffix, label, run }: { value: number; suffix?: string; label: string; run: boolean }) {
  const v = useCountUp(value, run);
  return (
    <div className="text-center">
      <p className="font-display text-4xl font-bold text-primary md:text-5xl">
        {v.toLocaleString("fr-FR")}
        {suffix}
      </p>
      <p className="mt-2 text-sm font-medium text-background/80">{label}</p>
    </div>
  );
}

function About() {
  const [statsRun, setStatsRun] = useState(false);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = statsRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setStatsRun(true);
          obs.disconnect();
        }
      },
      { threshold: 0.3 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const values = [
    {
      t: "Être courageux",
      d: "Nous prenons des initiatives et nous nous améliorons en continu pour bâtir une agriculture plus juste.",
      icon: "harvest",
    },
    {
      t: "Être humains",
      d: "Les relations humaines restent au centre de tout : chaque commande est une rencontre entre un producteur et un gourmet.",
      icon: "farmer1",
    },
    {
      t: "Être innovants",
      d: "La technologie aide les agriculteurs à atteindre directement les consommateurs, sans intermédiaire.",
      icon: "greenhouse",
    },
    {
      t: "Être durables",
      d: "Nous soutenons une agriculture responsable, respectueuse de la terre, de l'eau et des saisons.",
      icon: "orchard",
    },
  ] as const;

  const benefits = [
    ["Meilleur revenu pour les agriculteurs", "Sans intermédiaire, le producteur conserve une part bien plus juste du prix de vente."],
    ["Des produits plus frais", "Cueillis à la commande et livrés en 48h, vos fruits et légumes gardent tout leur goût."],
    ["Plus de transparence", "Vous savez qui cultive votre nourriture, où et comment."],
    ["Une économie locale renforcée", "Chaque achat soutient les familles paysannes et les territoires ruraux du Maroc."],
    ["Moins de gaspillage alimentaire", "La production à la demande réduit drastiquement les invendus et le gâchis."],
  ] as const;

  const team = [
    {
      name: "Youssef El Amrani",
      role: "Fondateur",
      bio: "Petit-fils d'agriculteur de la région du Souss, il a créé Nabta pour redonner leur juste place aux paysans marocains.",
      photo: "farmer7",
    },
    {
      name: "Salma Bennani",
      role: "Co-Fondatrice",
      bio: "Spécialiste du commerce équitable, elle pilote les partenariats avec les coopératives et les fermes familiales.",
      photo: "farmer2",
    },
    {
      name: "Karim Ouhadi",
      role: "Expert Agricole",
      bio: "Ingénieur agronome, il accompagne les producteurs vers des pratiques durables et une meilleure qualité.",
      photo: "farmer3",
    },
    {
      name: "Imane Tazi",
      role: "Responsable Technique",
      bio: "Elle conçoit la plateforme qui relie, en quelques clics, les fermes du terroir aux tables des Marocains.",
      photo: "farmer4",
    },
  ] as const;

  return (
    <div>
      {/* HERO */}
      <section className="relative">
        <Img
          src={img("heroFarm", 1800)}
          alt="Agriculteurs marocains dans leurs champs au lever du soleil"
          className="h-[80vh] min-h-[540px] w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/85 via-foreground/45 to-foreground/25" />
        <div className="container-px absolute inset-0 mx-auto flex max-w-7xl items-end pb-16 md:items-center md:pb-0">
          <div className="max-w-2xl text-background">
            <span className="inline-block rounded-full bg-primary/90 px-4 py-1.5 text-sm font-semibold">
              Notre Histoire
            </span>
            <h1 className="mt-5 font-display text-4xl font-bold leading-tight text-balance md:text-6xl">
              Nous sommes une solution pour l'agriculture créée avec les agriculteurs.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-background/90">
              Nabta Market connecte directement les producteurs marocains et les consommateurs.
              Notre mission : un terroir vivant, des paysans justement rémunérés et des produits frais
              cueillis à la commande.
            </p>
          </div>
        </div>
      </section>

      {/* OUR STORY */}
      <section className="container-px mx-auto max-w-7xl py-16 md:py-24">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">Notre histoire</span>
            <h2 className="mt-3 font-display text-3xl font-bold md:text-4xl">
              Tout a commencé dans un champ marocain
            </h2>
            <div className="mt-6 space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Nabta Market est né d'un constat simple et douloureux : trop de producteurs marocains
                travaillent une terre généreuse sans en vivre dignement. Entre la ferme et l'assiette,
                une longue chaîne d'intermédiaires capte l'essentiel de la valeur, pendant que le paysan,
                lui, reçoit des miettes.
              </p>
              <p>
                Nos agriculteurs affrontent des prix imposés, des récoltes invendues et une concurrence
                déséquilibrée. Pourtant, ce sont eux qui font vivre nos campagnes, qui préservent nos
                semences et qui nourrissent le pays. Nous avons voulu inverser ce rapport de force.
              </p>
              <p>
                La vente directe change tout. En reliant le producteur et le consommateur sans
                intermédiaire, nous redonnons au paysan le juste prix de son travail et offrons au
                gourmet des produits frais, traçables et pleins de goût. Soutenir l'agriculture
                marocaine, c'est soutenir des familles, des savoir-faire et des territoires entiers.
              </p>
              <p className="font-medium text-foreground">
                Nabta, c'est cette promesse : reconnecter la terre et la table, une commande à la fois.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Img src={img("farm1", 700)} alt="Ferme familiale marocaine" className="aspect-[3/4] w-full rounded-2xl object-cover shadow-card" />
            <Img src={img("harvest", 700)} alt="Récolte à la main" className="mt-8 aspect-[3/4] w-full rounded-2xl object-cover shadow-card" />
          </div>
        </div>
      </section>

      {/* OUR MISSION */}
      <section className="bg-cream/70">
        <div className="container-px mx-auto max-w-7xl py-16 md:py-24">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <Img
              src={img("field", 1000)}
              alt="Champ cultivé au Maroc"
              className="order-2 aspect-[4/3] w-full rounded-3xl object-cover shadow-card lg:order-1"
            />
            <div className="order-1 lg:order-2">
              <span className="text-sm font-semibold uppercase tracking-wider text-primary">Notre mission</span>
              <h2 className="mt-3 font-display text-3xl font-bold md:text-4xl">
                Une agriculture plus juste, plus durable
              </h2>
              <ul className="mt-6 space-y-4">
                {[
                  "Soutenir les producteurs locaux et leurs familles",
                  "Réduire les intermédiaires de la ferme à l'assiette",
                  "Améliorer le revenu des agriculteurs",
                  "Promouvoir une agriculture durable et responsable",
                  "Offrir aux consommateurs des produits toujours frais",
                ].map((m) => (
                  <li key={m} className="flex items-start gap-3">
                    <span className="mt-1 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                      ✓
                    </span>
                    <span className="text-foreground/90">{m}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* OUR VALUES */}
      <section className="container-px mx-auto max-w-7xl py-16 md:py-24">
        <div className="mb-10 max-w-2xl">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">Nos valeurs</span>
          <h2 className="mt-3 font-display text-3xl font-bold md:text-4xl">Ce qui nous fait avancer</h2>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v) => (
            <div
              key={v.t}
              className="group overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-transform hover:-translate-y-1"
            >
              <Img
                src={img(v.icon as never, 500)}
                alt={v.t}
                className="h-40 w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="p-6">
                <h3 className="font-display text-xl font-bold">{v.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{v.d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* WHY DIRECT SELLING */}
      <section className="bg-primary-dark text-background">
        <div className="container-px mx-auto max-w-7xl py-16 md:py-24">
          <div className="max-w-2xl">
            <span className="text-sm font-semibold uppercase tracking-wider text-background/70">
              La vente directe
            </span>
            <h2 className="mt-3 font-display text-3xl font-bold md:text-4xl">
              Que se passe-t-il quand on achète directement au producteur ?
            </h2>
            <p className="mt-4 text-background/85">
              Tout change. Le circuit court remet l'humain et le bon sens au cœur de l'alimentation.
            </p>
          </div>
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {benefits.map(([t, d]) => (
              <div key={t} className="rounded-2xl bg-background/10 p-6 backdrop-blur">
                <h3 className="font-display text-lg font-bold text-background">{t}</h3>
                <p className="mt-2 text-sm text-background/80">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOD WASTE */}
      <section className="container-px mx-auto max-w-7xl py-16 md:py-24">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="grid grid-cols-2 gap-4">
            <Img src={img("orchard", 700)} alt="Vergers marocains" className="mt-8 aspect-square w-full rounded-2xl object-cover shadow-card" />
            <Img src={img("harvest", 700)} alt="Légumes fraîchement récoltés" className="aspect-square w-full rounded-2xl object-cover shadow-card" />
          </div>
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">Anti-gaspillage</span>
            <h2 className="mt-3 font-display text-3xl font-bold md:text-4xl">
              Lutter contre le gaspillage alimentaire
            </h2>
            <div className="mt-6 space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Chaque année, des tonnes de fruits et légumes sont jetés simplement parce qu'ils sont
                trop petits, trop gros ou « imparfaits ». Ces produits sont pourtant tout aussi savoureux
                et nutritifs.
              </p>
              <p>
                En produisant à la commande et en valorisant les récoltes « moches mais bonnes », Nabta
                Market réduit drastiquement le gâchis. Nous croyons en une consommation responsable, qui
                respecte le travail de la terre et n'en gaspille pas les fruits.
              </p>
              <p className="font-medium text-foreground">
                Une agriculture durable commence par ne rien jeter de ce qu'elle produit de bon.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* TEAM */}
      <section className="bg-cream/70">
        <div className="container-px mx-auto max-w-7xl py-16 md:py-24">
          <div className="mb-10 max-w-2xl">
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">Notre équipe</span>
            <h2 className="mt-3 font-display text-3xl font-bold md:text-4xl">
              Les visages derrière Nabta
            </h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {team.map((m) => (
              <div
                key={m.name}
                className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-transform hover:-translate-y-1"
              >
                <Img src={img(m.photo as never, 500)} alt={m.name} className="aspect-square w-full object-cover" />
                <div className="p-5">
                  <h3 className="font-display text-lg font-bold">{m.name}</h3>
                  <p className="text-sm font-semibold text-primary">{m.role}</p>
                  <p className="mt-2 text-sm text-muted-foreground">{m.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* IMPACT */}
      <section ref={statsRef} className="relative overflow-hidden">
        <Img src={img("field", 1600)} alt="Champ marocain" className="h-full w-full object-cover absolute inset-0" />
        <div className="absolute inset-0 bg-foreground/80" />
        <div className="container-px relative mx-auto max-w-7xl py-16 md:py-20">
          <h2 className="mb-12 text-center font-display text-3xl font-bold text-background md:text-4xl">
            Notre impact
          </h2>
          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            <Stat value={10} suffix="+" label="Producteurs partenaires" run={statsRun} />
            <Stat value={38} suffix="+" label="Produits du terroir" run={statsRun} />
            <Stat value={8} label="Régions couvertes" run={statsRun} />
            <Stat value={2500} suffix="+" label="Commandes livrées" run={statsRun} />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container-px mx-auto max-w-7xl py-16 md:py-24">
        <div className="relative overflow-hidden rounded-3xl">
          <Img src={img("orchard", 1400)} alt="Verger marocain" className="h-full w-full object-cover absolute inset-0" />
          <div className="absolute inset-0 bg-primary-dark/75" />
          <div className="relative flex flex-col items-center px-6 py-16 text-center text-background md:py-20">
            <h2 className="max-w-2xl font-display text-3xl font-bold text-balance md:text-4xl">
              Acheter directement à la source.
            </h2>
            <p className="mt-4 max-w-xl text-background/90">
              Soutenez les producteurs marocains et savourez des produits frais, cueillis à la commande.
            </p>
            <Link
              to="/search"
              search={{ q: undefined, cat: undefined, region: undefined }}
              className="mt-8 rounded-full bg-background px-8 py-3.5 text-base font-semibold text-foreground shadow-lift transition-transform hover:scale-105"
            >
              Découvrir les produits
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
