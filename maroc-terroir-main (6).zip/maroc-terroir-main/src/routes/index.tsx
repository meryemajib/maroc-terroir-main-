import { createFileRoute, Link } from "@tanstack/react-router";
import { products, producers, img } from "@/data/catalog";
import { ProductCard } from "@/components/ProductCard";
import { ProducerCard } from "@/components/ProducerCard";
import { Img } from "@/components/Img";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nabta Market — Le terroir marocain en direct des producteurs" },
      {
        name: "description",
        content:
          "Découvrez fruits, légumes, huile d'olive et miel marocains livrés en circuit court, directement des fermes aux gourmets.",
      },
      { property: "og:image", content: img("heroFarm", 1200) },
    ],
  }),
  component: Home,
});

function Section({
  title,
  subtitle,
  children,
  className = "",
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`container-px mx-auto max-w-7xl py-14 ${className}`}>
      <div className="mb-8 max-w-2xl">
        <h2 className="text-3xl font-bold md:text-4xl">{title}</h2>
        {subtitle && <p className="mt-3 text-muted-foreground">{subtitle}</p>}
      </div>
      {children}
    </section>
  );
}

function Home() {
  const weekly = products.filter((p) => p.category === "Légumes" || p.category === "Fruits").slice(0, 4);
  const demanded = products.filter((p) => p.demanded).slice(0, 4);
  const pioneers = products.filter((p) => p.pioneer).slice(0, 4);
  const featuredProducers = producers.slice(0, 4);

  const steps = [
    { n: "1", t: "Choisir un produit", d: "Parcourez fruits, légumes et produits du terroir cueillis à la commande." },
    { n: "2", t: "Ajouter au panier", d: "Composez votre panier de saison auprès de plusieurs producteurs." },
    { n: "3", t: "Passer commande", d: "Validez en quelques clics, votre commande est préparée à la ferme." },
    { n: "4", t: "Recevoir sa commande", d: "Livraison en circuit court, en 48h, au plus frais." },
  ];

  return (
    <div>
      {/* HERO */}
      <section className="relative">
        <Img
          src={img("heroFarm", 1800)}
          alt="Ferme marocaine au lever du soleil"
          className="h-[78vh] min-h-[520px] w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/75 via-foreground/40 to-transparent" />
        <div className="container-px absolute inset-0 mx-auto flex max-w-7xl items-center">
          <div className="max-w-xl text-background">
            <span className="inline-block rounded-full bg-primary/90 px-4 py-1.5 text-sm font-semibold">
              Agriculture durable · Circuits courts
            </span>
            <h1 className="mt-5 font-display text-4xl font-bold leading-tight text-balance md:text-6xl">
              Le meilleur du terroir marocain, en direct des producteurs
            </h1>
            <p className="mt-5 max-w-md text-lg text-background/90">
              Fruits, légumes, huile d'olive et miel cueillis à la commande et livrés chez vous.
              Sans intermédiaire, au juste prix.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/search"
                search={{ q: undefined, cat: undefined, region: undefined }}
                className="rounded-full bg-primary px-7 py-3.5 text-base font-semibold text-primary-foreground shadow-lift transition-transform hover:scale-105"
              >
                Découvrir les produits
              </Link>
              <Link
                to="/producers"
                className="rounded-full border border-background/40 bg-background/10 px-7 py-3.5 text-base font-semibold text-background backdrop-blur transition-colors hover:bg-background/20"
              >
                Nos producteurs
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* trust strip */}
      <div className="border-b border-border bg-cream">
        <div className="container-px mx-auto grid max-w-7xl grid-cols-2 gap-6 py-8 md:grid-cols-4">
          {[
            ["10+", "Producteurs partenaires"],
            ["100%", "Origine Maroc"],
            ["48h", "Livraison en circuit court"],
            ["0", "Intermédiaire"],
          ].map(([n, l]) => (
            <div key={l} className="text-center">
              <p className="font-display text-3xl font-bold text-primary">{n}</p>
              <p className="mt-1 text-sm text-muted-foreground">{l}</p>
            </div>
          ))}
        </div>
      </div>

      {/* PRODUITS DE LA SEMAINE */}
      <Section
        title="Produits de la semaine"
        subtitle="Une sélection de fruits et légumes de saison cueillis cette semaine par nos producteurs."
      >
        <div className="grid grid-cols-2 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {weekly.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link
            to="/search"
            search={{ q: undefined, cat: undefined, region: undefined }}
            className="inline-flex rounded-full bg-primary px-7 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary-dark"
          >
            Voir tous les produits
          </Link>
        </div>
      </Section>

      {/* PRODUITS LES PLUS DEMANDÉS */}
      <div className="bg-cream/60">
        <Section
          title="Produits les plus demandés"
          subtitle="Les pépites du terroir plébiscitées par notre communauté, livrées directement de la ferme."
        >
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {demanded.map((p) => (
              <ProductCard key={p.id} product={p} large />
            ))}
          </div>
        </Section>
      </div>

      {/* LES PIONNIERS */}
      <Section
        title="Les pionniers de l'agriculture durable"
        subtitle="Des produits d'exception issus de fermes qui réinventent une agriculture respectueuse de la terre."
      >
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {pioneers.map((p) => (
            <ProductCard key={p.id} product={p} large />
          ))}
        </div>
      </Section>

      {/* PRODUCTEURS À DÉCOUVRIR */}
      <div className="bg-cream/60">
        <Section
          title="Producteurs à découvrir"
          subtitle="Derrière chaque produit, une famille, une ferme et une histoire. Découvrez celles et ceux qui cultivent votre assiette."
        >
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {featuredProducers.map((p) => (
              <ProducerCard key={p.id} producer={p} />
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link
              to="/producers"
              className="inline-flex rounded-full bg-primary px-7 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary-dark"
            >
              Voir tous les producteurs
            </Link>
          </div>
        </Section>
      </div>

      {/* COMMENT ÇA MARCHE */}
      <Section
        title="Comment ça marche"
        subtitle="De la ferme à votre table en quatre étapes simples."
      >
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s) => (
            <div
              key={s.n}
              className="rounded-2xl border border-border bg-card p-7 shadow-soft transition-transform hover:-translate-y-1"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary font-display text-xl font-bold text-primary-foreground">
                {s.n}
              </div>
              <h3 className="mt-5 text-lg font-semibold">{s.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA band */}
      <section className="relative overflow-hidden">
        <Img src={img("field", 1600)} alt="Champ marocain" className="h-72 w-full object-cover" />
        <div className="absolute inset-0 bg-primary-dark/70" />
        <div className="container-px absolute inset-0 mx-auto flex max-w-7xl flex-col items-start justify-center text-background">
          <h2 className="max-w-xl text-3xl font-bold md:text-4xl text-balance">
            Soutenez une agriculture juste et locale
          </h2>
          <p className="mt-3 max-w-lg text-background/90">
            Chaque commande rémunère équitablement le producteur et préserve le terroir marocain.
          </p>
          <Link
            to="/search"
            search={{ q: undefined, cat: undefined, region: undefined }}
            className="mt-6 rounded-full bg-background px-7 py-3 text-sm font-semibold text-foreground transition-transform hover:scale-105"
          >
            Commencer mes achats
          </Link>
        </div>
      </section>
    </div>
  );
}
