import { createFileRoute } from "@tanstack/react-router";
import { producers, img } from "@/data/catalog";
import { ProducerCard } from "@/components/ProducerCard";
import { Img } from "@/components/Img";

export const Route = createFileRoute("/producers")({
  head: () => ({
    meta: [
      { title: "Nos producteurs — Nabta Market" },
      { name: "description", content: "Rencontrez les producteurs marocains de Nabta Market : agriculteurs, apiculteurs et artisans engagés dans une agriculture durable." },
    ],
  }),
  component: ProducersPage,
});

function ProducersPage() {
  return (
    <div>
      <section className="relative">
        <Img src={img("farm2", 1600)} alt="Producteurs marocains" className="h-64 w-full object-cover" />
        <div className="absolute inset-0 bg-foreground/55" />
        <div className="container-px absolute inset-0 mx-auto flex max-w-7xl flex-col justify-center text-background">
          <h1 className="font-display text-4xl font-bold md:text-5xl">Nos producteurs</h1>
          <p className="mt-3 max-w-xl text-background/90">
            {producers.length} fermes et coopératives à travers le Maroc, unies par la passion d'une
            agriculture juste et durable.
          </p>
        </div>
      </section>

      <div className="container-px mx-auto max-w-7xl py-12">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {producers.map((p) => (
            <ProducerCard key={p.id} producer={p} />
          ))}
        </div>
      </div>
    </div>
  );
}
