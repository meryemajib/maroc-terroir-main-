import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { productById } from "@/data/catalog";
import { api } from "@/lib/api";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Validation de commande — Nabta Market" }] }),
  component: CheckoutPage,
});

const FEE = 25;

function CheckoutPage() {
  const { user } = useAuth();
  const { items, clear } = useCart();
  const navigate = useNavigate();
  const [done, setDone] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user) navigate({ to: "/login", search: { redirect: "/checkout" } });
  }, [user, navigate]);

  const lines = items.map((i) => ({ i, p: productById(i.id) })).filter((l) => l.p);
  const subtotal = lines.reduce((s, l) => s + l.p!.price * l.i.qty, 0);
  const total = subtotal > 0 ? subtotal + FEE : 0;

  if (!user) return null;

  if (done) {
    return (
      <div className="container-px mx-auto max-w-2xl py-24 text-center">
        <div className="rounded-3xl border border-border bg-card p-10 shadow-card">
          <h1 className="text-3xl font-bold text-primary">Commande confirmée</h1>
          <p className="mt-3 text-muted-foreground">
            Merci {user.name} ! Vos producteurs préparent votre commande. Vous recevrez un e-mail de suivi.
          </p>
          <Link to="/" className="mt-6 inline-flex rounded-full bg-primary px-7 py-3 font-semibold text-primary-foreground hover:bg-primary-dark">
            Retour à l'accueil
          </Link>
        </div>
      </div>
    );
  }

  if (lines.length === 0) {
    return (
      <div className="container-px mx-auto max-w-2xl py-24 text-center">
        <h1 className="text-2xl font-bold">Votre panier est vide</h1>
        <Link to="/search" search={{ q: undefined, cat: undefined, region: undefined }} className="mt-4 inline-block text-primary hover:underline">
          Découvrir les produits
        </Link>
      </div>
    );
  }

  return (
    <div className="container-px mx-auto max-w-5xl py-10">
      <h1 className="text-3xl font-bold md:text-4xl">Finaliser la commande</h1>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_340px]">
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            setSubmitting(true);
            try {
              await api.createOrder({
                customerName: String(fd.get("customerName") || user.name),
                phone: String(fd.get("phone") || ""),
                address: String(fd.get("address") || ""),
                city: String(fd.get("city") || ""),
                userEmail: user.email,
                items: items.map((i) => ({ productId: i.id, qty: i.qty })),
              });
            } catch {
              // Backend offline (e.g. Lovable preview) — proceed as demo order.
            } finally {
              setSubmitting(false);
              clear();
              setDone(true);
            }
          }}
          className="space-y-5 rounded-2xl border border-border bg-card p-6 shadow-soft"
        >
          <h2 className="text-lg font-semibold">Adresse de livraison</h2>
          {[
            { label: "Nom complet", name: "customerName", type: "text", def: user.name },
            { label: "Adresse", name: "address", type: "text" },
            { label: "Ville", name: "city", type: "text" },
            { label: "Téléphone", name: "phone", type: "tel" },
          ].map((f) => (
            <div key={f.label}>
              <label className="mb-1.5 block text-sm font-medium">{f.label}</label>
              <input
                type={f.type}
                name={f.name}
                required
                defaultValue={f.def}
                className="w-full rounded-xl border border-border bg-background px-4 py-2.5 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
          ))}

          <h2 className="pt-2 text-lg font-semibold">Mode de paiement</h2>
          <div className="rounded-xl border border-border bg-secondary/50 p-4 text-sm text-muted-foreground">
            Paiement à la livraison ou par carte. (Démonstration — aucun paiement réel.)
          </div>

          <button
            disabled={submitting}
            className="w-full rounded-full bg-primary py-3.5 font-semibold text-primary-foreground shadow-lift transition-transform hover:scale-[1.02] disabled:opacity-60"
          >
            {submitting ? "Traitement…" : `Procéder au paiement · ${total} DH`}
          </button>
        </form>


        <aside className="h-fit rounded-2xl border border-border bg-card p-6 shadow-card">
          <h2 className="text-lg font-semibold">Votre commande</h2>
          <ul className="mt-4 space-y-2 text-sm">
            {lines.map(({ i, p }) => (
              <li key={i.id} className="flex justify-between">
                <span className="text-muted-foreground">{p!.name} × {i.qty}</span>
                <span className="font-medium">{p!.price * i.qty} DH</span>
              </li>
            ))}
          </ul>
          <div className="mt-4 space-y-2 border-t border-border pt-4 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Sous-total</span><span>{subtotal} DH</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Livraison</span><span>{FEE} DH</span></div>
            <div className="flex justify-between text-base font-bold"><span>Total</span><span>{total} DH</span></div>
          </div>
        </aside>
      </div>
    </div>
  );
}
