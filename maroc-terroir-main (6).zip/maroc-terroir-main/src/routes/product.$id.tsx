import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { productById, producerById, products, img } from "@/data/catalog";
import { ProductCard } from "@/components/ProductCard";
import { FarmMap } from "@/components/FarmMap";
import { Img } from "@/components/Img";
import { useCart } from "@/context/CartContext";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    const product = productById(params.id);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    const p = loaderData?.product;
    return {
      meta: [
        { title: p ? `${p.name} — Nabta Market` : "Produit — Nabta Market" },
        { name: "description", content: p?.description ?? "" },
        ...(p ? [{ property: "og:image", content: img(p.image, 1000) }] : []),
      ],
    };
  },
  notFoundComponent: () => (
    <div className="container-px mx-auto max-w-3xl py-24 text-center">
      <h1 className="text-2xl font-bold">Produit introuvable</h1>
      <Link to="/search" search={{ q: undefined, cat: undefined, region: undefined }} className="mt-4 inline-block text-primary hover:underline">
        Retour aux produits
      </Link>
    </div>
  ),
  component: ProductPage,
});

function ProductPage() {
  const { product } = Route.useLoaderData();
  const producer = producerById(product.producerId)!;
  const { add } = useCart();
  const [qty, setQty] = useState(1);
  const [active, setActive] = useState(0);

  const gallery = [product.image, ...producer.gallery.filter((g) => g !== product.image)].slice(0, 4);
  const similar = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const deliveryDate = new Date(Date.now() + 2 * 86400000).toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });

  return (
    <div className="container-px mx-auto max-w-7xl py-10">
      <nav className="mb-6 text-sm text-muted-foreground">
        <Link to="/" className="hover:text-primary">Accueil</Link>
        {" / "}
        <Link to="/search" search={{ q: undefined, cat: product.category, region: undefined }} className="hover:text-primary">
          {product.category}
        </Link>
        {" / "}
        <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2">
        {/* Gallery */}
        <div>
          <div className="group overflow-hidden rounded-3xl border border-border shadow-card">
            <Img
              src={img(gallery[active], 1000)}
              alt={product.name}
              className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
          </div>
          <div className="mt-4 grid grid-cols-4 gap-3">
            {gallery.map((g, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className={`overflow-hidden rounded-xl border-2 ${active === i ? "border-primary" : "border-transparent"}`}
              >
                <Img src={img(g, 240)} alt="" className="aspect-square w-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-secondary px-3 py-1 text-xs font-medium">{product.category}</span>
            {product.bio && (
              <span className="rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">BIO</span>
            )}
          </div>
          <h1 className="mt-3 text-4xl font-bold">{product.name}</h1>
          <Link to="/producer/$id" params={{ id: producer.id }} className="mt-2 inline-block text-primary-dark hover:underline">
            par {producer.name} · {producer.region}
          </Link>

          <p className="mt-4 leading-relaxed text-muted-foreground">{product.description}</p>

          <dl className="mt-6 grid grid-cols-2 gap-4 rounded-2xl border border-border bg-card p-5 text-sm">
            <div><dt className="text-muted-foreground">Origine</dt><dd className="font-medium">{product.origin}</dd></div>
            <div><dt className="text-muted-foreground">Conditionnement</dt><dd className="font-medium">{product.unit}</dd></div>
            <div><dt className="text-muted-foreground">Livraison estimée</dt><dd className="font-medium capitalize">{deliveryDate}</dd></div>
            <div><dt className="text-muted-foreground">Logistique</dt><dd className="font-medium">{product.delivery}</dd></div>
          </dl>

          <div className="mt-6 flex items-end justify-between">
            <p className="font-display text-4xl font-bold">
              {product.price} <span className="text-lg font-medium text-muted-foreground">DH</span>
            </p>
            <div className="flex items-center rounded-full border border-border">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-4 py-2 text-lg">−</button>
              <span className="w-10 text-center font-semibold">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} className="px-4 py-2 text-lg">+</button>
            </div>
          </div>

          <button
            onClick={() => add(product.id, qty)}
            className="mt-5 w-full rounded-full bg-primary py-4 text-lg font-semibold text-primary-foreground shadow-lift transition-transform hover:scale-[1.02]"
          >
            Ajouter au panier · {product.price * qty} DH
          </button>
          <Link
            to="/cart"
            className="mt-3 block w-full rounded-full border border-border py-3 text-center font-medium hover:bg-secondary"
          >
            Voir le panier
          </Link>
        </div>
      </div>

      {/* Meet the producer */}
      <section className="mt-16 rounded-3xl border border-border bg-cream/60 p-6 md:p-10">
        <h2 className="text-2xl font-bold">Rencontrez le producteur</h2>
        <div className="mt-6 grid gap-8 md:grid-cols-[200px_1fr]">
          <div className="overflow-hidden rounded-2xl shadow-card">
            <Img src={img(producer.portrait, 400)} alt={producer.name} className="aspect-[3/4] w-full object-cover" />
          </div>
          <div>
            <h3 className="text-xl font-semibold">{producer.name}</h3>
            <p className="text-primary-dark">{producer.city} · {producer.experience} ans d'expérience</p>
            <p className="mt-3 leading-relaxed text-muted-foreground">{producer.story}</p>
            <p className="mt-3 leading-relaxed text-muted-foreground">{producer.philosophy}</p>
            <Link
              to="/producer/$id"
              params={{ id: producer.id }}
              className="mt-4 inline-flex rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-dark"
            >
              Voir le profil complet
            </Link>
          </div>
        </div>
        <div className="mt-8">
          <h3 className="mb-3 text-lg font-semibold">Localisation de la ferme</h3>
          <FarmMap lat={producer.lat} lng={producer.lng} label={`${producer.name} — ${producer.city}`} />
        </div>
      </section>

      {/* Similar */}
      {similar.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-6 text-2xl font-bold">Produits similaires</h2>
          <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
            {similar.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
