import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { producerById, productsByProducer, img, type ImgKey } from "@/data/catalog";
import { ProductCard } from "@/components/ProductCard";
import { FarmMap } from "@/components/FarmMap";
import { Weather } from "@/components/Weather";
import { Img } from "@/components/Img";

export const Route = createFileRoute("/producer/$id")({
  loader: ({ params }) => {
    const producer = producerById(params.id);
    if (!producer) throw notFound();
    return { producer };
  },
  head: ({ loaderData }) => {
    const p = loaderData?.producer;
    return {
      meta: [
        { title: p ? `${p.name} — Producteur sur Nabta Market` : "Producteur" },
        { name: "description", content: p?.bio ?? "" },
        ...(p ? [{ property: "og:image", content: img(p.cover, 1200) }] : []),
      ],
    };
  },
  notFoundComponent: () => (
    <div className="container-px mx-auto max-w-3xl py-24 text-center">
      <h1 className="text-2xl font-bold">Producteur introuvable</h1>
      <Link to="/producers" className="mt-4 inline-block text-primary hover:underline">Tous les producteurs</Link>
    </div>
  ),
  component: ProducerPage,
});

function ProducerPage() {
  const { producer } = Route.useLoaderData();
  const items = productsByProducer(producer.id);

  return (
    <div>
      {/* Cover */}
      <section className="relative">
        <Img src={img(producer.cover, 1800)} alt={`Ferme de ${producer.name}`} className="h-80 w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 to-foreground/20" />
        <div className="container-px absolute inset-x-0 bottom-0 mx-auto flex max-w-7xl items-end gap-5 pb-8">
          <div className="h-28 w-28 shrink-0 overflow-hidden rounded-2xl border-4 border-background shadow-lift">
            <Img src={img(producer.portrait, 300)} alt={producer.name} className="h-full w-full object-cover" />
          </div>
          <div className="text-background">
            <h1 className="font-display text-3xl font-bold md:text-5xl">{producer.name}</h1>
            <p className="mt-1 text-background/90">
              {producer.region} · {producer.experience} ans d'expérience · {producer.productionType}
            </p>
          </div>
        </div>
      </section>

      <div className="container-px mx-auto max-w-7xl py-12">
        <div className="grid gap-12 lg:grid-cols-[1fr_340px]">
          {/* Story */}
          <div>
            <h2 className="text-2xl font-bold">L'histoire de {producer.name.split(" ")[0]}</h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">{producer.bio}</p>
            <p className="mt-4 leading-relaxed text-muted-foreground">{producer.story}</p>

            <h3 className="mt-8 text-xl font-semibold">Philosophie agricole</h3>
            <p className="mt-3 leading-relaxed text-muted-foreground">{producer.philosophy}</p>
            <p className="mt-3 leading-relaxed text-muted-foreground">
              Adepte d'une {producer.productionType.toLowerCase()}, {producer.name.split(" ")[0]} privilégie
              les méthodes respectueuses des sols, la biodiversité et le bien-être de tout l'écosystème de
              sa ferme. Chaque récolte est pensée pour durer, saison après saison.
            </p>

            {/* Gallery */}
            <h3 className="mt-10 text-xl font-semibold">La ferme en images</h3>
            <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
              {producer.gallery.map((g: ImgKey, i: number) => (
                <div key={i} className="overflow-hidden rounded-2xl shadow-soft">
                  <Img src={img(g, 500)} alt="Vue de la ferme" className="aspect-square w-full object-cover transition-transform duration-500 hover:scale-110" />
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            <div className="rounded-2xl border border-border bg-card p-6 shadow-soft">
              <h3 className="text-lg font-semibold">Informations de la ferme</h3>
              <dl className="mt-4 space-y-3 text-sm">
                {[
                  ["Région", producer.region],
                  ["Ville", producer.city],
                  ["Produits", `${items.length} références`],
                  ["Superficie", producer.farmSize],
                  ["Type de production", producer.productionType],
                  ["Expérience", `${producer.experience} ans`],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between border-b border-border pb-2 last:border-0">
                    <dt className="text-muted-foreground">{k}</dt>
                    <dd className="font-medium text-right">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <Weather base={producer.weatherBase} region={producer.region} />
          </aside>
        </div>

        {/* Map */}
        <section className="mt-14">
          <h2 className="mb-4 text-2xl font-bold">Localisation de la ferme</h2>
          <FarmMap lat={producer.lat} lng={producer.lng} label={`${producer.name} — ${producer.city}, ${producer.region}`} />
        </section>

        {/* Products */}
        <section className="mt-14">
          <h2 className="mb-6 text-2xl font-bold">Les produits de {producer.name.split(" ")[0]}</h2>
          <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
            {items.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
