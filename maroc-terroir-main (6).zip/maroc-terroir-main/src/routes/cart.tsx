import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { productById, producerById, img } from "@/data/catalog";
import { Img } from "@/components/Img";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Mon panier — Nabta Market" }] }),
  component: CartPage,
});

const FEE = 25;

function CartPage() {
  const { items, setQty, remove } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const lines = items
    .map((i) => ({ item: i, product: productById(i.id) }))
    .filter((l) => l.product);

  const subtotal = lines.reduce((s, l) => s + l.product!.price * l.item.qty, 0);
  const total = subtotal > 0 ? subtotal + FEE : 0;

  const checkout = () => {
    if (!user) {
      navigate({ to: "/login", search: { redirect: "/checkout" } });
    } else {
      navigate({ to: "/checkout" });
    }
  };

  if (lines.length === 0) {
    return (
      <div className="container-px mx-auto max-w-3xl py-24 text-center">
        <h1 className="text-3xl font-bold">Votre panier est vide</h1>
        <p className="mt-3 text-muted-foreground">Parcourez nos produits frais en direct des fermes marocaines.</p>
        <Link
          to="/search"
          search={{ q: undefined, cat: undefined, region: undefined }}
          className="mt-6 inline-flex rounded-full bg-primary px-7 py-3 font-semibold text-primary-foreground hover:bg-primary-dark"
        >
          Découvrir les produits
        </Link>
      </div>
    );
  }

  return (
    <div className="container-px mx-auto max-w-6xl py-10">
      <h1 className="text-3xl font-bold md:text-4xl">Mon panier</h1>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_340px]">
        <div className="space-y-4">
          {lines.map(({ item, product }) => {
            const prod = producerById(product!.producerId);
            return (
              <div key={item.id} className="flex gap-4 rounded-2xl border border-border bg-card p-4 shadow-soft">
                <Link to="/product/$id" params={{ id: product!.id }} className="shrink-0">
                  <Img src={img(product!.image, 200)} alt={product!.name} className="h-24 w-24 rounded-xl object-cover" />
                </Link>
                <div className="flex flex-1 flex-col">
                  <Link to="/product/$id" params={{ id: product!.id }} className="font-semibold hover:text-primary">
                    {product!.name}
                  </Link>
                  <p className="text-sm text-muted-foreground">{product!.unit} · {prod?.name}</p>
                  <div className="mt-auto flex items-center justify-between pt-3">
                    <div className="flex items-center rounded-full border border-border">
                      <button onClick={() => setQty(item.id, item.qty - 1)} className="px-3 py-1 text-lg">−</button>
                      <span className="w-8 text-center text-sm font-semibold">{item.qty}</span>
                      <button onClick={() => setQty(item.id, item.qty + 1)} className="px-3 py-1 text-lg">+</button>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-bold">{product!.price * item.qty} DH</span>
                      <button onClick={() => remove(item.id)} className="text-sm text-destructive hover:underline">
                        Retirer
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <aside className="h-fit rounded-2xl border border-border bg-card p-6 shadow-card">
          <h2 className="text-lg font-semibold">Récapitulatif</h2>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Sous-total</span><span className="font-medium">{subtotal} DH</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Livraison</span><span className="font-medium">{FEE} DH</span></div>
            <div className="flex justify-between border-t border-border pt-3 text-base font-bold"><span>Total</span><span>{total} DH</span></div>
          </div>
          <button
            onClick={checkout}
            className="mt-6 w-full rounded-full bg-primary py-3.5 font-semibold text-primary-foreground shadow-lift transition-transform hover:scale-[1.02]"
          >
            Passer la commande
          </button>
          <Link to="/search" search={{ q: undefined, cat: undefined, region: undefined }} className="mt-3 block text-center text-sm text-primary hover:underline">
            Continuer mes achats
          </Link>
        </aside>
      </div>
    </div>
  );
}
