import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { img } from "@/data/catalog";
import { Img } from "@/components/Img";

interface S {
  redirect?: string;
}

export const Route = createFileRoute("/login")({
  validateSearch: (s: Record<string, unknown>): S => ({
    redirect: typeof s.redirect === "string" ? s.redirect : undefined,
  }),
  head: () => ({ meta: [{ title: "Connexion — Nabta Market" }] }),
  component: LoginPage,
});

function LoginPage() {
  const { redirect } = Route.useSearch();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (await login(email, password)) {
      navigate({ to: redirect || "/" });
    } else {
      setError("Identifiants invalides. Vérifiez votre e-mail et mot de passe (min. 4 caractères).");
    }
  };

  return (
    <div className="grid min-h-[calc(100vh-4rem)] lg:grid-cols-2">
      <div className="relative hidden lg:block">
        <Img src={img("orchard", 1200)} alt="Verger marocain" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-primary-dark/40" />
        <div className="absolute bottom-10 left-10 max-w-sm text-background">
          <h2 className="font-display text-3xl font-bold">Le terroir marocain, en direct.</h2>
          <p className="mt-2 text-background/90">Connectez-vous pour finaliser vos commandes en circuit court.</p>
        </div>
      </div>

      <div className="container-px flex items-center justify-center bg-cream py-16">
        <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 shadow-card">
          <h1 className="text-3xl font-bold">Connexion</h1>
          {redirect && (
            <p className="mt-3 rounded-xl bg-accent/60 px-4 py-3 text-sm text-accent-foreground">
              Veuillez vous connecter ou créer un compte pour continuer.
            </p>
          )}

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium">E-mail</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="vous@exemple.com"
                className="w-full rounded-xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium">Mot de passe</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}

            <button className="w-full rounded-full bg-primary py-3.5 font-semibold text-primary-foreground shadow-lift transition-transform hover:scale-[1.02]">
              Se connecter
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Pas encore de compte ?{" "}
            <Link
              to="/register"
              search={{ redirect }}
              className="font-semibold text-primary hover:underline"
            >
              Créer un compte
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
