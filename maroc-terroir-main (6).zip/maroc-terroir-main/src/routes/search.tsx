import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { products, categories, regions, producerById } from "@/data/catalog";
import { ProductCard } from "@/components/ProductCard";

interface SearchParams {
  q?: string;
  cat?: string;
  region?: string;
}

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>): SearchParams => ({
    q: typeof s.q === "string" ? s.q : undefined,
    cat: typeof s.cat === "string" ? s.cat : undefined,
    region: typeof s.region === "string" ? s.region : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Rechercher des produits — Nabta Market" },
      { name: "description", content: "Recherchez et filtrez fruits, légumes et produits du terroir marocain par catégorie, prix et région." },
    ],
  }),
  component: SearchPage,
});

const MAX = 130;

function SearchPage() {
  const { q, cat, region } = Route.useSearch();
  const navigate = useNavigate();
  const [query, setQuery] = useState(q ?? "");
  const [maxPrice, setMaxPrice] = useState(MAX);

  const update = (patch: Partial<SearchParams>) =>
    navigate({ to: "/search", search: (prev: SearchParams) => ({ ...prev, ...patch }) });

  const filtered = products.filter((p) => {
    const prod = producerById(p.producerId);
    const matchesQ = !q || `${p.name} ${p.category} ${prod?.name ?? ""}`.toLowerCase().includes(q.toLowerCase());
    const matchesCat = !cat || p.category === cat;
    const matchesRegion = !region || prod?.region === region;
    const matchesPrice = p.price <= maxPrice;
    return matchesQ && matchesCat && matchesRegion && matchesPrice;
  });

  return (
    <div className="container-px mx-auto max-w-7xl py-10">
      <h1 className="text-3xl font-bold md:text-4xl">Rechercher des produits</h1>
      <p className="mt-2 text-muted-foreground">
        {filtered.length} produit{filtered.length > 1 ? "s" : ""} disponible{filtered.length > 1 ? "s" : ""}
      </p>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          update({ q: query || undefined });
        }}
        className="mt-6 flex gap-3"
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Tomates, huile d'olive, miel…"
          className="flex-1 rounded-full border border-border bg-card px-5 py-3 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
        />
        <button className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground hover:bg-primary-dark">
          Rechercher
        </button>
      </form>

      <div className="mt-8 grid gap-8 lg:grid-cols-[260px_1fr]">
        {/* Filters */}
        <aside className="h-fit rounded-2xl border border-border bg-card p-5 shadow-soft">
          <h3 className="font-semibold">Catégories</h3>
          <div className="mt-3 space-y-1.5">
            <button
              onClick={() => update({ cat: undefined })}
              className={`block w-full rounded-lg px-3 py-2 text-left text-sm ${!cat ? "bg-primary text-primary-foreground" : "hover:bg-secondary"}`}
            >
              Toutes
            </button>
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => update({ cat: c })}
                className={`block w-full rounded-lg px-3 py-2 text-left text-sm ${cat === c ? "bg-primary text-primary-foreground" : "hover:bg-secondary"}`}
              >
                {c}
              </button>
            ))}
          </div>

          <h3 className="mt-6 font-semibold">Région</h3>
          <select
            value={region ?? ""}
            onChange={(e) => update({ region: e.target.value || undefined })}
            className="mt-3 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
          >
            <option value="">Toutes les régions</option>
            {regions.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>

          <h3 className="mt-6 font-semibold">Prix maximum</h3>
          <input
            type="range"
            min={5}
            max={MAX}
            value={maxPrice}
            onChange={(e) => setMaxPrice(Number(e.target.value))}
            className="mt-3 w-full accent-[var(--color-primary)]"
          />
          <p className="mt-1 text-sm text-muted-foreground">Jusqu'à {maxPrice} DH</p>

          <button
            onClick={() => {
              setQuery("");
              setMaxPrice(MAX);
              navigate({ to: "/search", search: { q: undefined, cat: undefined, region: undefined } });
            }}
            className="mt-6 w-full rounded-full border border-border py-2 text-sm font-medium hover:bg-secondary"
          >
            Réinitialiser
          </button>
        </aside>

        {/* Results */}
        {filtered.length ? (
          <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 xl:grid-cols-4">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        ) : (
          <div className="grid place-items-center rounded-2xl border border-dashed border-border py-24 text-center">
            <p className="text-lg font-semibold">Aucun produit trouvé</p>
            <p className="mt-1 text-sm text-muted-foreground">Essayez d'élargir vos filtres.</p>
          </div>
        )}
      </div>
    </div>
  );
}
