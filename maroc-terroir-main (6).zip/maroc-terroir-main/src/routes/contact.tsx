import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { img } from "@/data/catalog";
import { Img } from "@/components/Img";
import { api } from "@/lib/api";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Nabta Market | Parlons agriculture locale" },
      {
        name: "description",
        content:
          "Contactez Nabta Market : questions sur nos produits, livraisons, partenariats producteurs. Écrivez-nous, nous répondons sous 24h.",
      },
      { property: "og:title", content: "Contactez Nabta Market" },
      {
        property: "og:description",
        content:
          "Une question sur nos produits fermiers marocains ? Notre équipe vous répond avec plaisir.",
      },
      { property: "og:image", content: img("heroFarm", 1200) },
    ],
  }),
  component: Contact,
});

const infoCards = [
  {
    title: "Email",
    value: "contact@nabtamarket.ma",
    detail: "Réponse sous 24h",
  },
  {
    title: "Téléphone",
    value: "+212 5 22 00 00 00",
    detail: "Lun — Ven, 9h à 18h",
  },
  {
    title: "Adresse",
    value: "12 Rue des Oliviers, Casablanca",
    detail: "Maroc, 20000",
  },
  {
    title: "Horaires",
    value: "Lun — Ven : 9h — 18h",
    detail: "Samedi : 9h — 13h",
  },
];

const faqs = [
  {
    q: "Comment sont livrés mes produits ?",
    a: "Nos produits sont récoltés à la commande et livrés en circuit court directement depuis la ferme jusqu'à votre porte, sous 24 à 48h selon votre région.",
  },
  {
    q: "Quelles régions livrez-vous ?",
    a: "Nous livrons actuellement dans les principales villes du Maroc : Casablanca, Rabat, Marrakech, Agadir, Fès et Tanger, avec une couverture qui s'étend chaque mois.",
  },
  {
    q: "Puis-je devenir producteur partenaire ?",
    a: "Bien sûr ! Nous accompagnons les agriculteurs marocains dans la vente directe. Écrivez-nous via ce formulaire en précisant « Partenariat producteur » comme sujet.",
  },
  {
    q: "Quels sont les modes de paiement acceptés ?",
    a: "Vous pouvez payer par carte bancaire, virement ou en espèces à la livraison selon votre région.",
  },
  {
    q: "Comment suivre ma commande ?",
    a: "Une fois votre commande confirmée, vous recevez un email avec le statut de préparation et de livraison en temps réel.",
  },
];

function Contact() {
  const [sent, setSent] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.contact({
        fullName: form.name,
        email: form.email,
        phone: form.phone,
        subject: form.subject,
        message: form.message,
      });
    } catch {
      // Backend offline (e.g. Lovable preview) — show success anyway.
    }
    setSent(true);
    setForm({ name: "", email: "", phone: "", subject: "", message: "" });
  };

  const field =
    "w-full rounded-xl border border-border bg-secondary/50 px-4 py-3 text-sm outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20";

  return (
    <div className="bg-background">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <Img
          src={img("heroFarm", 1600)}
          alt="Ferme marocaine sous le soleil"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 via-foreground/60 to-foreground/30" />
        <div className="container-px relative mx-auto max-w-7xl py-24 md:py-32">
          <div className="max-w-2xl">
            <span className="inline-block rounded-full bg-primary/90 px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-primary-foreground">
              Nous contacter
            </span>
            <h1 className="mt-5 font-display text-4xl font-bold leading-tight text-background md:text-6xl">
              Parlons de votre prochaine récolte
            </h1>
            <p className="mt-5 max-w-xl text-lg text-background/85">
              Une question sur nos produits, une commande ou un partenariat producteur ?
              Notre équipe vous répond avec plaisir sous 24 heures.
            </p>
          </div>
        </div>
      </section>

      {/* Info cards */}
      <section className="container-px mx-auto -mt-14 max-w-7xl">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {infoCards.map((c) => (
            <div
              key={c.title}
              className="rounded-2xl border border-border bg-background p-6 shadow-sm transition-shadow hover:shadow-lg"
            >
              <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {c.title}
              </h3>
              <p className="mt-2 font-display text-lg font-semibold text-foreground">{c.value}</p>
              <p className="mt-1 text-sm text-muted-foreground">{c.detail}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Form + Map */}
      <section className="container-px mx-auto max-w-7xl py-16 md:py-20">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-3xl font-bold text-foreground">Envoyez-nous un message</h2>
            <p className="mt-2 text-muted-foreground">
              Remplissez le formulaire ci-dessous et nous reviendrons vers vous rapidement.
            </p>

            {sent && (
              <div className="mt-6 rounded-xl border border-primary/30 bg-primary/10 px-5 py-4 text-sm font-medium text-primary">
                Merci ! Votre message a bien été envoyé. Nous vous répondrons sous 24h.
              </div>
            )}

            <form onSubmit={submit} className="mt-6 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-foreground">Nom complet</label>
                  <input required value={form.name} onChange={set("name")} placeholder="Votre nom" className={field} />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-foreground">Adresse email</label>
                  <input required type="email" value={form.email} onChange={set("email")} placeholder="vous@exemple.com" className={field} />
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-foreground">Téléphone</label>
                  <input type="tel" value={form.phone} onChange={set("phone")} placeholder="+212 6 00 00 00 00" className={field} />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-foreground">Sujet</label>
                  <input required value={form.subject} onChange={set("subject")} placeholder="Objet de votre message" className={field} />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-foreground">Message</label>
                <textarea required rows={5} value={form.message} onChange={set("message")} placeholder="Votre message…" className={field} />
              </div>
              <button
                type="submit"
                className="rounded-full bg-primary px-7 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary-dark"
              >
                Envoyer le message
              </button>
            </form>
          </div>

          <div className="flex flex-col">
            <h2 className="font-display text-3xl font-bold text-foreground">Où nous trouver</h2>
            <p className="mt-2 text-muted-foreground">
              Notre siège se situe au cœur de Casablanca, proche des routes agricoles.
            </p>
            <div className="mt-6 flex-1 overflow-hidden rounded-2xl border border-border shadow-sm">
              <iframe
                title="Carte Nabta Market"
                src="https://www.google.com/maps?q=Casablanca,Morocco&output=embed"
                className="h-full min-h-[380px] w-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-cream">
        <div className="container-px mx-auto max-w-3xl py-16 md:py-20">
          <div className="text-center">
            <h2 className="font-display text-3xl font-bold text-foreground md:text-4xl">Questions fréquentes</h2>
            <p className="mt-3 text-muted-foreground">
              Tout ce que vous devez savoir avant de commander chez Nabta Market.
            </p>
          </div>
          <div className="mt-10 space-y-3">
            {faqs.map((f, i) => (
              <div key={i} className="overflow-hidden rounded-xl border border-border bg-background">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                >
                  <span className="font-medium text-foreground">{f.q}</span>
                  <span className="text-xl font-light text-primary">{openFaq === i ? "−" : "+"}</span>
                </button>
                {openFaq === i && (
                  <p className="px-5 pb-5 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container-px mx-auto max-w-7xl py-16 md:py-20">
        <div className="relative overflow-hidden rounded-3xl bg-primary px-8 py-14 text-center md:px-16 md:py-20">
          <h2 className="font-display text-3xl font-bold text-primary-foreground md:text-4xl">
            Prêt à goûter le meilleur du terroir marocain ?
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-primary-foreground/85">
            Découvrez nos produits frais en direct des producteurs, ou écrivez-nous pour toute question.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link
              to="/search"
              search={{ q: undefined, cat: undefined, region: undefined }}
              className="rounded-full bg-background px-7 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-cream"
            >
              Découvrir les produits
            </Link>
            <a
              href="mailto:contact@nabtamarket.ma"
              className="rounded-full border border-primary-foreground/40 px-7 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary-foreground/10"
            >
              Nous écrire
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
