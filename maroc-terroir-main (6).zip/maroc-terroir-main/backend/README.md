# Nabta Market — Backend (Spring Boot + MySQL)

REST API backend for the **Nabta Market** frontend (TanStack Start React app).
Built to match the frontend catalog in `src/data/catalog.ts` (producers, products),
the auth flow (`AuthContext`), the cart/checkout flow (`CartContext`), and the
contact form.

> This project runs **outside Lovable**, locally in IntelliJ / VS Code.

---

## 1. Requirements

- **Java 17+** (JDK)
- **Maven 3.9+** (or use the IDE's bundled Maven)
- **MySQL 8+** running locally

## 2. Database setup

The app auto-creates the schema (`createDatabaseIfNotExist=true` + `ddl-auto=update`),
but make sure MySQL is running and the credentials match.

Default credentials in `src/main/resources/application.properties`:

```
spring.datasource.url=jdbc:mysql://localhost:3306/nabta_market?...&createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=root
```

Change `username` / `password` to match your local MySQL, or create the DB manually:

```sql
CREATE DATABASE nabta_market CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## 3. Run

```bash
cd backend
./mvnw spring-boot:run      # or: mvn spring-boot:run
```

In IntelliJ: open the `backend` folder, let it import the Maven project,
then run `NabtaMarketApplication`.

The API starts at **http://localhost:8080**.

On first run it **seeds** all 10 producers and 45 products from the frontend
catalog, plus an admin account:

- **Email:** `admin@nabta.ma`
- **Password:** `admin123`

Disable seeding with `app.seed.enabled=false`.

---

## 4. API Reference

### Auth — `/api/auth`
| Method | Path              | Body                              | Notes                     |
|--------|-------------------|-----------------------------------|---------------------------|
| POST   | `/register`       | `{name,email,password}`           | returns JWT               |
| POST   | `/login`          | `{email,password}`                | returns JWT               |
| GET    | `/me`             | —                                 | `Authorization: Bearer …` |

Response: `{ token, name, email, role }`

### Products — `/api/products`  (public GET)
| Method | Path                                   | Notes                                   |
|--------|----------------------------------------|-----------------------------------------|
| GET    | `/`                                    | `?category=`, `?producerId=`, `?q=`     |
| GET    | `/featured` `/demanded` `/pioneer`     | curated lists                           |
| GET    | `/{id}`                                | single product (e.g. `p1`)              |
| POST   | `/`                                    | create (auth)                           |
| PUT    | `/{id}`                                | update (auth)                           |
| DELETE | `/{id}`                                | delete (ADMIN)                          |

### Producers — `/api/producers`  (public GET)
| Method | Path                    | Notes                        |
|--------|-------------------------|------------------------------|
| GET    | `/`                     | `?region=`                   |
| GET    | `/{id}`                 | single producer slug         |
| GET    | `/{id}/products`        | products of a producer       |
| POST/PUT/DELETE | ...            | manage (auth / ADMIN delete) |

### Orders — `/api/orders`
| Method | Path         | Body                                                              |
|--------|--------------|------------------------------------------------------------------|
| POST   | `/`          | `{customerName,phone,address,city,userEmail,items:[{productId,qty}]}` |
| GET    | `/{id}`      | order detail (auth)                                              |
| GET    | `/?email=`   | orders for a user (auth)                                         |

Totals are computed server-side from real product prices.

### Contact — `/api/contact`
| Method | Path | Body                                          | Notes            |
|--------|------|-----------------------------------------------|------------------|
| POST   | `/`  | `{fullName,email,phone,subject,message}`      | public           |
| GET    | `/`  | —                                             | ADMIN only       |

---

## 5. Security

- Stateless **JWT** auth (`Authorization: Bearer <token>`).
- Passwords hashed with **BCrypt**.
- Roles: `USER`, `ADMIN`.
- CORS origins configured in `application.properties` (`app.cors.allowed-origins`)
  — includes the Vite dev server (`http://localhost:5173`). Add your deployed
  frontend origin there.
- **Change** `app.jwt.secret` before deploying anywhere.

---

## 6. Connecting the frontend later

Point the React app at `http://localhost:8080`. Product/producer JSON shapes
match `src/data/catalog.ts` field names (`id`, `name`, `price`, `category`,
`producerId`, `image`, `origin`, `bio`, `featured`, `pioneer`, `demanded`, …),
so wiring is a direct swap of the local catalog for `fetch` calls.

Note: `image`, `portrait`, `cover`, and `gallery` return the same **image keys**
used by the frontend `img()` helper — the frontend keeps resolving them to
photos, so no image URLs need to change.
