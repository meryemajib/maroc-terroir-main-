package com.nabta.market.controller;

import com.nabta.market.entity.Product;
import com.nabta.market.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductRepository repo;

    public ProductController(ProductRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Product> all(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String producerId,
            @RequestParam(required = false) String q) {
        if (q != null && !q.isBlank())
            return repo.findByNameContainingIgnoreCaseOrOriginContainingIgnoreCase(q, q);
        if (category != null) return repo.findByCategory(category);
        if (producerId != null) return repo.findByProducerId(producerId);
        return repo.findAll();
    }

    @GetMapping("/featured")
    public List<Product> featured() { return repo.findByFeaturedTrue(); }

    @GetMapping("/demanded")
    public List<Product> demanded() { return repo.findByDemandedTrue(); }

    @GetMapping("/pioneer")
    public List<Product> pioneer() { return repo.findByPioneerTrue(); }

    @GetMapping("/{id}")
    public Product one(@PathVariable String id) {
        return repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found"));
    }

    @PostMapping
    public Product create(@RequestBody Product product) { return repo.save(product); }

    @PutMapping("/{id}")
    public Product update(@PathVariable String id, @RequestBody Product product) {
        product.setId(id);
        return repo.save(product);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) { repo.deleteById(id); }
}
