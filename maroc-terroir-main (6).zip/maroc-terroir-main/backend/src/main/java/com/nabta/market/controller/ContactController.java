package com.nabta.market.controller;

import com.nabta.market.dto.ContactRequest;
import com.nabta.market.entity.ContactMessage;
import com.nabta.market.repository.ContactMessageRepository;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/contact")
public class ContactController {

    private final ContactMessageRepository repo;

    public ContactController(ContactMessageRepository repo) {
        this.repo = repo;
    }

    @PostMapping
    public Map<String, Object> submit(@Valid @RequestBody ContactRequest req) {
        ContactMessage saved = repo.save(ContactMessage.builder()
                .fullName(req.fullName())
                .email(req.email())
                .phone(req.phone())
                .subject(req.subject())
                .message(req.message())
                .build());
        return Map.of("success", true, "id", saved.getId(),
                "message", "Merci ! Votre message a bien été envoyé.");
    }

    /** Admin-only (secured in SecurityConfig) */
    @GetMapping
    public List<ContactMessage> all() {
        return repo.findAll();
    }
}
