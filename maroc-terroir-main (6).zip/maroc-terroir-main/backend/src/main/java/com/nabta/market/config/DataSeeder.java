package com.nabta.market.config;

import com.nabta.market.entity.*;
import com.nabta.market.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

/**
 * Seeds producers, products and an admin account on first run.
 * Mirrors the frontend catalog (src/data/catalog.ts).
 * Disable with app.seed.enabled=false
 */
@Configuration
@ConditionalOnProperty(name = "app.seed.enabled", havingValue = "true", matchIfMissing = true)
public class DataSeeder {

    private static final String D = "Livraison 48h • Cueilli à la commande";

    @Bean
    CommandLineRunner seed(ProducerRepository producers,
                           ProductRepository products,
                           UserRepository users,
                           PasswordEncoder encoder) {
        return args -> {
            if (users.count() == 0) {
                users.save(User.builder()
                        .name("Admin Nabta")
                        .email("admin@nabta.ma")
                        .password(encoder.encode("admin123"))
                        .role(Role.ADMIN)
                        .build());
            }

            if (producers.count() == 0) {
                producers.saveAll(seedProducers());
            }
            if (products.count() == 0) {
                products.saveAll(seedProducts());
            }
        };
    }

    private Producer pr(String id, String name, String city, String region, int exp,
                        String farmSize, String type, String portrait, String cover,
                        String bio, String story, String philosophy, List<String> gallery,
                        double lat, double lng, int weatherBase) {
        return Producer.builder()
                .id(id).name(name).city(city).region(region).experience(exp)
                .farmSize(farmSize).productionType(type).portrait(portrait).cover(cover)
                .bio(bio).story(story).philosophy(philosophy).gallery(gallery)
                .lat(lat).lng(lng).weatherBase(weatherBase)
                .build();
    }

    private List<Producer> seedProducers() {
        return List.of(
            pr("ahmed-benali", "Ahmed Benali", "Meknès", "Fès-Meknès", 24, "18 hectares",
                "Agriculture biologique", "farmer1", "farm1",
                "Producteur d'olives et d'huile d'olive vierge extra dans les plaines fertiles de Meknès.",
                "Ahmed a repris l'oliveraie familiale il y a plus de deux décennies. Sur les terres rouges du Saïs, il cultive des oliviers centenaires selon des méthodes transmises de génération en génération, en respectant le rythme naturel des saisons.",
                "« La terre nous donne exactement ce qu'on lui offre. » Ahmed refuse tout pesticide de synthèse et pratique une irrigation raisonnée goutte-à-goutte.",
                List.of("farm1", "oliveoil", "olives", "field"), 33.8956, -5.5547, 22),
            pr("fatima-zahra", "Fatima Zahra", "Agadir", "Souss-Massa", 16, "9 hectares",
                "Agriculture durable", "farmer2", "greenhouse",
                "Spécialiste des agrumes et des tomates sous le soleil généreux du Souss.",
                "Fatima dirige une exploitation maraîchère moderne près d'Agadir. Pionnière de la culture sous serre raisonnée, elle emploie une dizaine de femmes de sa région et défend une agriculture à taille humaine.",
                "Elle privilégie les variétés locales adaptées au climat et la lutte biologique contre les nuisibles.",
                List.of("greenhouse", "tomato", "orange", "harvest"), 30.4278, -9.5981, 25),
            pr("hassan-el-idrissi", "Hassan El Idrissi", "Taroudant", "Souss-Massa", 30, "12 hectares",
                "Agriculture biologique", "farmer3", "argan",
                "Gardien des arganiers et producteur d'amandes et d'huile d'argan.",
                "Au cœur de l'arganeraie, Hassan perpétue un savoir-faire ancestral. Il travaille main dans la main avec une coopérative féminine pour produire une huile d'argan d'exception.",
                "Préserver l'arganier, arbre emblématique du Maroc, est au centre de chacune de ses décisions.",
                List.of("argan", "almond", "field", "farm2"), 30.4703, -8.8769, 26),
            pr("youssef-amrani", "Youssef Amrani", "Marrakech", "Marrakech-Safi", 12, "7 hectares",
                "Agriculture durable", "farmer4", "orchard",
                "Arboriculteur passionné de grenades, figues et abricots.",
                "Jeune ingénieur agronome revenu à la terre, Youssef a planté des vergers diversifiés au pied de l'Atlas. Il mise sur l'agroécologie et les circuits courts.",
                "« Vendre directement, sans intermédiaire, c'est rendre justice au travail du paysan. »",
                List.of("orchard", "pomegranate", "fig", "apricot"), 31.6295, -7.9811, 27),
            pr("khadija-tazi", "Khadija Tazi", "Béni Mellal", "Béni Mellal-Khénifra", 19, "15 hectares",
                "Agriculture biologique", "farmer5", "field",
                "Maraîchère bio et productrice d'agrumes au pied du Moyen Atlas.",
                "Khadija a converti l'exploitation familiale au bio en 2010. Elle cultive une grande diversité de légumes de saison pour les marchés de la région.",
                "La rotation des cultures et le compost maison sont ses meilleurs alliés.",
                List.of("field", "carrot", "lemon", "harvest"), 32.3373, -6.3498, 23),
            pr("rachid-bennani", "Rachid Bennani", "Khénifra", "Béni Mellal-Khénifra", 28, "Apiculture nomade",
                "Apiculture naturelle", "farmer6", "farm3",
                "Apiculteur de montagne, producteur de miels naturels du Moyen Atlas.",
                "Rachid déplace ses ruches au gré des floraisons, du thym sauvage à l'eucalyptus. Un miel récolté à la main, jamais chauffé.",
                "Respecter l'abeille, c'est respecter tout l'écosystème de la montagne.",
                List.of("farm3", "honey", "field", "orchard"), 32.9394, -5.6685, 18),
            pr("nadia-bouzidi", "Nadia Bouzidi", "El Jadida", "Casablanca-Settat", 14, "11 hectares",
                "Agriculture durable", "farmer7", "farm2",
                "Productrice laitière fermière sur la côte atlantique.",
                "Nadia élève un troupeau de vaches en plein air et transforme le lait à la ferme en fromages frais et beurre artisanal.",
                "Le bien-être animal d'abord : pâturage libre et alimentation naturelle.",
                List.of("farm2", "cheese", "milk", "field"), 33.2316, -8.5007, 21),
            pr("omar-fassi", "Omar Fassi", "Berkane", "Oriental", 22, "20 hectares",
                "Agriculture biologique", "farmer8", "orchard",
                "Roi des agrumes de Berkane, célèbre pour ses clémentines et oranges.",
                "Omar cultive les fameux agrumes de Berkane, une région labellisée. Ses vergers s'étendent le long de la Moulouya.",
                "La qualité avant la quantité : chaque fruit est cueilli à pleine maturité.",
                List.of("orchard", "orange", "lemon", "harvest"), 34.92, -2.32, 24),
            pr("salma-ouazzani", "Salma Ouazzani", "Chefchaouen", "Tanger-Tétouan-Al Hoceïma", 10, "5 hectares",
                "Agriculture de montagne", "farmer9", "field",
                "Cultive légumes anciens et plantes aromatiques dans le Rif.",
                "Sur les terrasses verdoyantes du Rif, Salma fait revivre des variétés anciennes oubliées et des herbes aromatiques de montagne.",
                "Sauvegarder la biodiversité paysanne, semence après semence.",
                List.of("field", "spinach", "pepper", "farm1"), 35.1688, -5.2636, 17),
            pr("brahim-sahli", "Brahim Sahli", "Errachidia", "Drâa-Tafilalet", 35, "Palmeraie 14 ha",
                "Agriculture oasienne", "farmer10", "farm3",
                "Maître phoeniciculteur, producteur de dattes Majhoul du Tafilalet.",
                "Dans la palmeraie ancestrale du Tafilalet, Brahim cultive les dattes les plus prisées du Maroc selon le système oasien millénaire des trois étages.",
                "L'oasis est un trésor fragile que chaque génération doit transmettre intact.",
                List.of("farm3", "date", "field", "harvest"), 31.9314, -4.4244, 28)
        );
    }

    private int pid = 0;

    private Product p(String name, String unit, double price, String category, String producerId,
                      String image, String origin, String description, String delivery,
                      boolean bio, boolean featured, boolean pioneer, boolean demanded) {
        return Product.builder()
                .id("p" + (++pid))
                .name(name).unit(unit).price(price).category(category).producerId(producerId)
                .image(image).origin(origin).description(description).delivery(delivery)
                .bio(bio).featured(featured).pioneer(pioneer).demanded(demanded)
                .build();
    }

    private List<Product> seedProducts() {
        return List.of(
            // ---- Légumes ----
            p("Pommes de terre", "1 kg", 6, "Légumes", "khadija-tazi", "potato", "Béni Mellal", "Pommes de terre à chair ferme, idéales pour toutes vos préparations.", D, false, false, false, false),
            p("Oignons", "1 kg", 5, "Légumes", "khadija-tazi", "onion", "Béni Mellal", "Oignons jaunes savoureux, récoltés à pleine maturité.", D, false, false, false, false),
            p("Tomates", "1 kg", 8, "Légumes", "fatima-zahra", "tomato", "Agadir", "Tomates juteuses cultivées sous le soleil du Souss.", D, false, false, false, true),
            p("Carottes", "1 kg", 7, "Légumes", "khadija-tazi", "carrot", "Béni Mellal", "Carottes croquantes et sucrées du Moyen Atlas.", D, false, false, false, false),
            p("Courgettes", "1 kg", 7, "Légumes", "fatima-zahra", "zucchini", "Agadir", "Courgettes tendres cueillies jeunes.", D, false, false, false, false),
            p("Poivrons", "1 kg", 12, "Légumes", "fatima-zahra", "pepper", "Agadir", "Poivrons colorés et charnus.", D, false, false, false, false),
            p("Aubergines", "1 kg", 9, "Légumes", "salma-ouazzani", "eggplant", "Chefchaouen", "Aubergines violettes brillantes du Rif.", D, false, false, false, false),
            p("Concombres", "1 kg", 6, "Légumes", "fatima-zahra", "cucumber", "Agadir", "Concombres frais et croquants.", D, false, false, false, false),
            p("Ail", "500 g", 14, "Légumes", "salma-ouazzani", "garlic", "Chefchaouen", "Ail de montagne parfumé.", D, false, false, false, false),
            p("Chou vert", "pièce", 8, "Légumes", "salma-ouazzani", "cabbage", "Chefchaouen", "Chou frais récolté du jour.", D, false, false, false, false),
            p("Brocoli", "500 g", 13, "Légumes", "khadija-tazi", "broccoli", "Béni Mellal", "Brocoli bio riche en saveurs.", D, true, false, false, false),
            p("Épinards", "500 g", 9, "Légumes", "salma-ouazzani", "spinach", "Chefchaouen", "Épinards frais en bottes.", D, false, false, false, false),
            p("Petits pois", "1 kg", 15, "Légumes", "khadija-tazi", "peas", "Béni Mellal", "Petits pois doux à écosser.", D, false, false, false, false),
            p("Betteraves", "1 kg", 8, "Légumes", "khadija-tazi", "beet", "Béni Mellal", "Betteraves rouges sucrées.", D, false, false, false, false),
            p("Potiron", "1 kg", 7, "Légumes", "salma-ouazzani", "pumpkin", "Chefchaouen", "Potiron à la chair orangée et fondante.", D, false, false, false, false),
            p("Navets", "1 kg", 6, "Légumes", "khadija-tazi", "turnip", "Béni Mellal", "Navets tendres de saison.", D, false, false, false, false),
            p("Laitue", "pièce", 5, "Légumes", "fatima-zahra", "lettuce", "Agadir", "Laitue fraîche et craquante.", D, false, false, false, false),
            p("Chou-fleur", "pièce", 10, "Légumes", "salma-ouazzani", "cauliflower", "Chefchaouen", "Chou-fleur blanc et ferme.", D, false, false, false, false),
            p("Tomates cerises", "500 g", 11, "Légumes", "fatima-zahra", "tomato", "Agadir", "Tomates cerises sucrées à croquer.", D, false, false, false, false),
            p("Piments verts", "500 g", 9, "Légumes", "fatima-zahra", "pepper", "Agadir", "Piments verts doux et parfumés.", D, false, false, false, false),

            // ---- Fruits ----
            p("Citrons", "1 kg", 10, "Fruits", "omar-fassi", "lemon", "Berkane", "Citrons juteux et parfumés de Berkane.", D, true, false, false, true),
            p("Oranges", "1 kg", 9, "Fruits", "omar-fassi", "orange", "Berkane", "Oranges sucrées gorgées de soleil.", D, false, false, false, true),
            p("Oranges BIO", "2 kg", 28, "Fruits", "omar-fassi", "orange", "Berkane", "Oranges certifiées biologiques de Berkane.", D, true, false, true, true),
            p("Mangues", "1 kg", 35, "Fruits", "youssef-amrani", "mango", "Marrakech", "Mangues fondantes et parfumées.", D, false, true, false, true),
            p("Avocats", "1 kg", 32, "Fruits", "youssef-amrani", "avocado", "Marrakech", "Avocats crémeux à point.", D, false, true, false, true),
            p("Pommes", "1 kg", 12, "Fruits", "salma-ouazzani", "apple", "Chefchaouen", "Pommes croquantes de montagne.", D, false, false, false, false),
            p("Bananes", "1 kg", 14, "Fruits", "fatima-zahra", "banana", "Agadir", "Bananes locales sucrées.", D, false, false, false, false),
            p("Fraises", "500 g", 18, "Fruits", "nadia-bouzidi", "strawberry", "El Jadida", "Fraises parfumées de la côte.", D, false, false, false, false),
            p("Raisin", "1 kg", 16, "Fruits", "youssef-amrani", "grape", "Marrakech", "Raisin de table juteux.", D, false, false, false, false),
            p("Figues", "1 kg", 22, "Fruits", "youssef-amrani", "fig", "Marrakech", "Figues fraîches et mielleuses.", D, false, true, false, false),
            p("Grenades", "1 kg", 18, "Fruits", "youssef-amrani", "pomegranate", "Marrakech", "Grenades aux grains rubis.", D, false, true, false, false),
            p("Pastèque", "pièce", 25, "Fruits", "fatima-zahra", "watermelon", "Agadir", "Pastèque rafraîchissante et sucrée.", D, false, false, false, false),
            p("Melon", "pièce", 16, "Fruits", "fatima-zahra", "melon", "Agadir", "Melon parfumé à chair orangée.", D, false, false, false, false),
            p("Pêches", "1 kg", 17, "Fruits", "youssef-amrani", "peach", "Marrakech", "Pêches juteuses de plein été.", D, false, false, false, false),
            p("Abricots", "1 kg", 19, "Fruits", "youssef-amrani", "apricot", "Marrakech", "Abricots sucrés cueillis mûrs.", D, false, true, false, false),
            p("Grenades BIO", "2 kg", 38, "Fruits", "youssef-amrani", "pomegranate", "Marrakech", "Grenades biologiques de l'Atlas.", D, true, false, true, false),
            p("Clémentines", "2 kg", 24, "Fruits", "omar-fassi", "orange", "Berkane", "Clémentines sucrées sans pépins.", D, false, false, true, false),
            p("Dattes Majhoul", "500 g", 60, "Fruits secs", "brahim-sahli", "date", "Errachidia", "Dattes Majhoul moelleuses du Tafilalet.", D, false, true, true, true),

            // ---- Artisanal ----
            p("Huile d'olive vierge extra", "1 L", 85, "Huile d'olive", "ahmed-benali", "oliveoil", "Meknès", "Huile d'olive première pression à froid, fruitée et équilibrée.", "Livraison 72h • Bouteille verre", true, true, true, true),
            p("Miel naturel de montagne", "500 g", 90, "Miel", "rachid-bennani", "honey", "Khénifra", "Miel cru de thym sauvage, récolté à la main.", "Livraison 72h • Pot verre", true, true, true, true),
            p("Amandes", "500 g", 55, "Fruits secs", "hassan-el-idrissi", "almond", "Taroudant", "Amandes croquantes de l'arganeraie.", D, false, false, true, true),
            p("Huile d'argan alimentaire", "250 ml", 120, "Huile d'olive", "hassan-el-idrissi", "argan", "Taroudant", "Huile d'argan pure, pressée par une coopérative féminine.", "Livraison 72h • Bouteille verre", true, true, false, false),
            p("Fromage frais fermier", "250 g", 35, "Produits laitiers", "nadia-bouzidi", "cheese", "El Jadida", "Fromage frais artisanal au lait cru.", "Livraison 48h • Chaîne du froid", false, true, false, false),
            p("Beurre fermier", "250 g", 28, "Produits laitiers", "nadia-bouzidi", "milk", "El Jadida", "Beurre baratté à la ferme.", "Livraison 48h • Chaîne du froid", false, false, false, false),
            p("Olives vertes", "1 kg", 30, "Huile d'olive", "ahmed-benali", "olives", "Meknès", "Olives vertes préparées de façon traditionnelle.", D, false, false, false, false)
        );
    }
}
