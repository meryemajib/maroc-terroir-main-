package com.nabta.market.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "products")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Product {

    @Id
    @Column(length = 40)
    private String id; // e.g. "p1"

    @Column(nullable = false)
    private String name;

    private String unit;
    private double price;
    private String category;

    @Column(name = "producer_id")
    private String producerId;

    private String image;
    private String origin;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String delivery;

    private boolean bio;
    private boolean featured;
    private boolean pioneer;
    private boolean demanded;
}
