package com.nabta.market.entity;

public enum Role {
    USER,
    ADMIN
}
