package com.nabta.market.repository;

import com.nabta.market.entity.Producer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProducerRepository extends JpaRepository<Producer, String> {
    List<Producer> findByRegion(String region);
}
