package com.nabta.market.controller;

import com.nabta.market.entity.Producer;
import com.nabta.market.entity.Product;
import com.nabta.market.repository.ProducerRepository;
import com.nabta.market.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/producers")
public class ProducerController {

    private final ProducerRepository repo;
    private final ProductRepository products;

    public ProducerController(ProducerRepository repo, ProductRepository products) {
        this.repo = repo;
        this.products = products;
    }

    @GetMapping
    public List<Producer> all(@RequestParam(required = false) String region) {
        return region != null ? repo.findByRegion(region) : repo.findAll();
    }

    @GetMapping("/{id}")
    public Producer one(@PathVariable String id) {
        return repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Producer not found"));
    }

    @GetMapping("/{id}/products")
    public List<Product> productsOf(@PathVariable String id) {
        return products.findByProducerId(id);
    }

    @PostMapping
    public Producer create(@RequestBody Producer producer) { return repo.save(producer); }

    @PutMapping("/{id}")
    public Producer update(@PathVariable String id, @RequestBody Producer producer) {
        producer.setId(id);
        return repo.save(producer);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) { repo.deleteById(id); }
}
