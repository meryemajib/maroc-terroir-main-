package com.nabta.market.repository;

import com.nabta.market.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, String> {
    List<Product> findByCategory(String category);
    List<Product> findByProducerId(String producerId);
    List<Product> findByFeaturedTrue();
    List<Product> findByDemandedTrue();
    List<Product> findByPioneerTrue();
    List<Product> findByNameContainingIgnoreCaseOrOriginContainingIgnoreCase(String name, String origin);
}
