package com.nabta.market.dto;

import jakarta.validation.constraints.*;

import java.util.List;

public class OrderDtos {

    public record OrderItemRequest(
            @NotBlank String productId,
            @Min(1) int qty
    ) {}

    public record CreateOrderRequest(
            @NotBlank String customerName,
            @NotBlank String phone,
            @NotBlank String address,
            String city,
            String userEmail,
            @NotEmpty List<OrderItemRequest> items
    ) {}
}
