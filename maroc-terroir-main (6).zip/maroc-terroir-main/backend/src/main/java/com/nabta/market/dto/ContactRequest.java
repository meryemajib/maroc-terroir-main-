package com.nabta.market.dto;

import jakarta.validation.constraints.*;

public record ContactRequest(
        @NotBlank String fullName,
        @Email @NotBlank String email,
        String phone,
        @NotBlank String subject,
        @NotBlank String message
) {}
