package com.nabta.market.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "producers")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Producer {

    @Id
    @Column(length = 80)
    private String id; // slug, e.g. "ahmed-benali"

    @Column(nullable = false)
    private String name;

    private String city;
    private String region;
    private int experience;
    private String farmSize;
    private String productionType;

    /** image keys resolved by the frontend catalog */
    private String portrait;
    private String cover;

    @Column(columnDefinition = "TEXT")
    private String bio;

    @Column(columnDefinition = "TEXT")
    private String story;

    @Column(columnDefinition = "TEXT")
    private String philosophy;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "producer_gallery", joinColumns = @JoinColumn(name = "producer_id"))
    @Column(name = "image_key")
    @Builder.Default
    private List<String> gallery = new ArrayList<>();

    private double lat;
    private double lng;
    private int weatherBase;
}
