package com.nabta.market.controller;

import com.nabta.market.dto.OrderDtos.*;
import com.nabta.market.entity.Order;
import com.nabta.market.entity.OrderItem;
import com.nabta.market.entity.Product;
import com.nabta.market.repository.OrderRepository;
import com.nabta.market.repository.ProductRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderRepository orders;
    private final ProductRepository products;

    public OrderController(OrderRepository orders, ProductRepository products) {
        this.orders = orders;
        this.products = products;
    }

    @PostMapping
    public Order create(@Valid @RequestBody CreateOrderRequest req) {
        Order order = Order.builder()
                .customerName(req.customerName())
                .phone(req.phone())
                .address(req.address())
                .city(req.city())
                .userEmail(req.userEmail())
                .status("PENDING")
                .build();

        double total = 0;
        for (OrderItemRequest it : req.items()) {
            Product p = products.findById(it.productId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST,
                            "Unknown product: " + it.productId()));
            OrderItem item = OrderItem.builder()
                    .productId(p.getId())
                    .productName(p.getName())
                    .unitPrice(p.getPrice())
                    .qty(it.qty())
                    .build();
            total += p.getPrice() * it.qty();
            order.addItem(item);
        }
        order.setTotal(total);
        return orders.save(order);
    }

    @GetMapping("/{id}")
    public Order one(@PathVariable Long id) {
        return orders.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found"));
    }

    @GetMapping
    public List<Order> byUser(@RequestParam String email) {
        return orders.findByUserEmailOrderByCreatedAtDesc(email);
    }
}
